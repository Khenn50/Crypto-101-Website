# Crypto 101 Website - Complete Project Export

## Project Overview
A comprehensive cryptocurrency education platform with dark charcoal theme and neon accents. Features include crypto ratings, educational classroom, portfolio tracker, and user profiles with free/premium tiers.

## Tech Stack
- React 18.3.1
- React Router 7.13.0
- Tailwind CSS 4.1.12
- TypeScript
- Vite 6.3.5
- Lucide React (icons)

## Project Structure
```
/src/
  /app/
    App.tsx                 # Main app component with RouterProvider
    routes.tsx             # React Router configuration
    /components/
      Layout.tsx           # Main layout wrapper with navigation
      Navigation.tsx       # Site navigation with premium upgrade
      VideoPlayer.tsx      # Reusable video player component
      /ui/                 # Pre-existing UI components (shadcn)
    /data/
      cryptoData.ts        # Crypto ratings data
    /pages/
      Home.tsx             # Landing page with welcome video
      CryptoRatings.tsx    # List of all crypto ratings
      CryptoDetail.tsx     # Individual crypto detail with video
      Classroom.tsx        # Educational courses
      Portfolio.tsx        # User portfolio tracker
      About.tsx            # About company page
      Profile.tsx          # User profile page
  /styles/
    theme.css              # Custom theme with neon colors
    index.css              # Main styles
    tailwind.css           # Tailwind imports
    fonts.css              # Font imports
```

## Dependencies (package.json)
```json
{
  "dependencies": {
    "react": "18.3.1",
    "react-dom": "18.3.1",
    "react-router": "7.13.0",
    "lucide-react": "0.487.0",
    "@radix-ui/react-*": "various",
    "tailwind-merge": "3.2.0",
    "class-variance-authority": "0.7.1"
  }
}
```

---

## File Contents

### `/src/app/App.tsx`
```tsx
import { RouterProvider } from "react-router";
import { router } from "./routes";

export default function App() {
  return <RouterProvider router={router} />;
}
```

### `/src/app/routes.tsx`
```tsx
import { createBrowserRouter } from "react-router";
import { Layout } from "./components/Layout";
import { Home } from "./pages/Home";
import { CryptoRatings } from "./pages/CryptoRatings";
import { CryptoDetail } from "./pages/CryptoDetail";
import { Classroom } from "./pages/Classroom";
import { Portfolio } from "./pages/Portfolio";
import { About } from "./pages/About";
import { Profile } from "./pages/Profile";

export const router = createBrowserRouter([
  {
    path: "/",
    Component: Layout,
    children: [
      { index: true, Component: Home },
      { path: "ratings", Component: CryptoRatings },
      { path: "crypto/:id", Component: CryptoDetail },
      { path: "classroom", Component: Classroom },
      { path: "portfolio", Component: Portfolio },
      { path: "about", Component: About },
      { path: "profile", Component: Profile },
    ],
  },
]);
```

### `/src/app/components/Layout.tsx`
```tsx
import { Outlet } from "react-router";
import { Navigation } from "./Navigation";

export function Layout() {
  return (
    <div className="min-h-screen bg-background">
      <Navigation />
      <main className="container mx-auto px-4 py-8">
        <Outlet />
      </main>
    </div>
  );
}
```

### `/src/app/components/Navigation.tsx`
```tsx
import { Link, useLocation } from "react-router";
import { Button } from "./ui/button";
import { Crown, User } from "lucide-react";
import { useState } from "react";

export function Navigation() {
  const location = useLocation();
  const [isPremium, setIsPremium] = useState(false);

  const navItems = [
    { path: "/", label: "Home" },
    { path: "/ratings", label: "Crypto Ratings" },
    { path: "/classroom", label: "Classroom" },
    { path: "/portfolio", label: "Portfolio" },
    { path: "/about", label: "About" },
  ];

  const isActive = (path: string) => {
    if (path === "/") {
      return location.pathname === "/";
    }
    return location.pathname.startsWith(path);
  };

  return (
    <nav className="border-b border-border bg-card">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between h-16">
          <div className="flex items-center gap-8">
            <Link to="/" className="flex items-center gap-2">
              <div className="w-8 h-8 bg-gradient-to-br from-neon-cyan to-neon-magenta rounded-lg" />
              <span className="text-xl text-neon-green">[Company Name]</span>
            </Link>
            
            <div className="hidden md:flex gap-1">
              {navItems.map((item) => (
                <Link key={item.path} to={item.path}>
                  <Button
                    variant="ghost"
                    className={
                      isActive(item.path)
                        ? "text-neon-green hover:text-neon-green"
                        : "text-muted-foreground hover:text-foreground"
                    }
                  >
                    {item.label}
                  </Button>
                </Link>
              ))}
            </div>
          </div>

          <div className="flex items-center gap-4">
            {!isPremium && (
              <Button
                onClick={() => setIsPremium(true)}
                className="bg-gradient-to-r from-neon-magenta to-neon-cyan text-white hover:opacity-90"
              >
                <Crown className="w-4 h-4 mr-2" />
                Upgrade to Premium
              </Button>
            )}
            {isPremium && (
              <div className="flex items-center gap-2 px-3 py-1 rounded-full bg-gradient-to-r from-neon-magenta/20 to-neon-cyan/20 border border-neon-cyan">
                <Crown className="w-4 h-4 text-neon-yellow" />
                <span className="text-sm text-neon-yellow">Premium</span>
              </div>
            )}
            <Link to="/profile">
              <Button variant="ghost" size="icon">
                <User className="w-5 h-5" />
              </Button>
            </Link>
          </div>
        </div>
      </div>
    </nav>
  );
}
```

### `/src/app/components/VideoPlayer.tsx`
```tsx
import { Card } from "./ui/card";
import { Play } from "lucide-react";

interface VideoPlayerProps {
  title?: string;
  videoUrl?: string;
  thumbnailUrl?: string;
  description?: string;
}

export function VideoPlayer({ 
  title, 
  videoUrl = "", 
  thumbnailUrl = "",
  description 
}: VideoPlayerProps) {
  return (
    <Card className="overflow-hidden">
      <div className="relative aspect-video bg-gradient-to-br from-muted to-muted/50 flex items-center justify-center group cursor-pointer">
        {thumbnailUrl ? (
          <img 
            src={thumbnailUrl} 
            alt={title || "Video thumbnail"} 
            className="w-full h-full object-cover"
          />
        ) : (
          <div className="text-center space-y-4">
            <div className="w-20 h-20 mx-auto rounded-full bg-neon-green/20 border-2 border-neon-green flex items-center justify-center group-hover:scale-110 transition-transform">
              <Play className="w-10 h-10 text-neon-green fill-neon-green" />
            </div>
            <div className="text-muted-foreground">
              {title || "Video Player"}
            </div>
          </div>
        )}
        <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
          <div className="w-20 h-20 rounded-full bg-neon-green/90 flex items-center justify-center">
            <Play className="w-10 h-10 text-black fill-black ml-1" />
          </div>
        </div>
      </div>
      {(title || description) && (
        <div className="p-4">
          {title && <h3 className="font-medium mb-1">{title}</h3>}
          {description && <p className="text-sm text-muted-foreground">{description}</p>}
        </div>
      )}
    </Card>
  );
}
```

### `/src/app/data/cryptoData.ts`
```tsx
export interface CryptoRating {
  id: string;
  name: string;
  symbol: string;
  rating: number;
  price: string;
  marketCap: string;
  change24h: number;
  category: string;
  description: string;
  technology: string;
  team: string;
  adoption: string;
  risks: string[];
  opportunities: string[];
  videoUrl?: string;
  videoTitle?: string;
  videoDescription?: string;
  isPremium?: boolean;
}

export const cryptoRatings: CryptoRating[] = [
  {
    id: "bitcoin",
    name: "Bitcoin",
    symbol: "BTC",
    rating: 9.2,
    price: "$45,230",
    marketCap: "$880B",
    change24h: 2.5,
    category: "Store of Value",
    description: "The first and most well-known cryptocurrency, often referred to as digital gold. Bitcoin introduced blockchain technology and remains the most secure and decentralized network.",
    technology: "Bitcoin uses a Proof-of-Work consensus mechanism with the SHA-256 hashing algorithm. The network is highly secure with the largest hash rate of any blockchain.",
    team: "Created by Satoshi Nakamoto (pseudonymous). Now maintained by a global community of developers led by core maintainers.",
    adoption: "Widely accepted as a store of value. Institutional adoption growing. Legal tender in El Salvador and Central African Republic.",
    risks: ["High energy consumption", "Scalability limitations", "Regulatory uncertainty"],
    opportunities: ["Growing institutional adoption", "Lightning Network development", "Store of value narrative strengthening"],
    videoTitle: "Bitcoin Explained: Digital Gold & The Future of Money",
    videoDescription: "Deep dive into Bitcoin's technology, use cases, and why it's considered the most secure cryptocurrency",
  },
  {
    id: "ethereum",
    name: "Ethereum",
    symbol: "ETH",
    rating: 8.9,
    price: "$2,420",
    marketCap: "$290B",
    change24h: 3.2,
    category: "Smart Contract Platform",
    description: "The leading smart contract platform enabling decentralized applications, DeFi protocols, and NFTs. Ethereum pioneered programmable blockchain technology.",
    technology: "Transitioned to Proof-of-Stake with the Merge in 2022. EVM (Ethereum Virtual Machine) is the most widely adopted smart contract execution environment.",
    team: "Founded by Vitalik Buterin and team. Ethereum Foundation oversees development with contributions from thousands of developers globally.",
    adoption: "Dominant platform for DeFi and NFTs. Extensive developer ecosystem. Supported by major enterprises through the Enterprise Ethereum Alliance.",
    risks: ["High gas fees during congestion", "Competition from newer platforms", "Complexity of upgrades"],
    opportunities: ["Layer 2 scaling solutions", "Growing DeFi ecosystem", "Institutional interest in staking"],
    videoTitle: "Ethereum: The World Computer - Smart Contracts & DeFi",
    videoDescription: "Understanding Ethereum's technology, ecosystem, and why it powers the majority of decentralized applications",
  },
  {
    id: "cardano",
    name: "Cardano",
    symbol: "ADA",
    rating: 7.8,
    price: "$0.52",
    marketCap: "$18B",
    change24h: 1.8,
    category: "Smart Contract Platform",
    description: "A research-driven blockchain platform with a focus on sustainability, scalability, and peer-reviewed development.",
    technology: "Uses Ouroboros Proof-of-Stake consensus. Development follows academic peer-review process. Plutus smart contract platform.",
    team: "Founded by Charles Hoskinson (Ethereum co-founder). Developed by IOHK, Emurgo, and Cardano Foundation.",
    adoption: "Growing DeFi ecosystem. Focus on developing nations. Partnerships in Africa for identity solutions.",
    risks: ["Slower development pace", "Smaller ecosystem than competitors", "Complexity may limit adoption"],
    opportunities: ["Academic rigor", "Focus on sustainability", "Emerging market adoption"],
    videoTitle: "Cardano: The Academic Approach to Blockchain",
    videoDescription: "Explore Cardano's peer-reviewed development process and focus on sustainability",
    isPremium: true,
  },
  {
    id: "solana",
    name: "Solana",
    symbol: "SOL",
    rating: 7.5,
    price: "$98",
    marketCap: "$43B",
    change24h: -1.2,
    category: "Smart Contract Platform",
    description: "High-performance blockchain designed for speed and low costs, popular for DeFi and NFT applications.",
    technology: "Uses Proof-of-History combined with Proof-of-Stake. Capable of 65,000+ transactions per second theoretically.",
    team: "Founded by Anatoly Yakovenko. Backed by major VCs including a16z and Multicoin Capital.",
    adoption: "Popular for NFTs and gaming. Growing DeFi ecosystem. Major exchange integrations.",
    risks: ["Network outages in the past", "Centralization concerns", "High hardware requirements for validators"],
    opportunities: ["Fast transaction speeds", "Low fees", "Strong developer community"],
    videoTitle: "Solana: Speed & Scale in Blockchain",
    videoDescription: "How Solana achieves high throughput and low costs for NFTs and DeFi applications",
    isPremium: true,
  },
  {
    id: "polkadot",
    name: "Polkadot",
    symbol: "DOT",
    rating: 7.6,
    price: "$7.20",
    marketCap: "$10B",
    change24h: 2.1,
    category: "Interoperability",
    description: "A multi-chain network enabling different blockchains to transfer messages and value in a trust-free fashion.",
    technology: "Uses Nominated Proof-of-Stake. Relay chain coordinates parachains (parallel chains). Built with Substrate framework.",
    team: "Founded by Gavin Wood (Ethereum co-founder). Developed by Parity Technologies and Web3 Foundation.",
    adoption: "Growing parachain ecosystem. Focus on cross-chain interoperability. Used by various blockchain projects.",
    risks: ["Parachain auction complexity", "Competition in interoperability space", "Governance challenges"],
    opportunities: ["Cross-chain future", "Substrate framework adoption", "Unique architecture"],
    videoTitle: "Polkadot: Connecting the Blockchain Ecosystem",
    videoDescription: "Understanding Polkadot's multi-chain architecture and parachain technology",
    isPremium: true,
  },
  {
    id: "ripple",
    name: "Ripple",
    symbol: "XRP",
    rating: 6.9,
    price: "$0.58",
    marketCap: "$32B",
    change24h: 0.5,
    category: "Payment Network",
    description: "Digital payment protocol designed for fast and low-cost international money transfers.",
    technology: "Uses XRP Ledger with Federated Byzantine Agreement consensus. Transactions settle in 3-5 seconds.",
    team: "Created by Ripple Labs. Strong connections with traditional financial institutions.",
    adoption: "Partnerships with banks and payment providers. RippleNet used for cross-border payments.",
    risks: ["Ongoing SEC lawsuit", "Centralization concerns", "Bank adoption uncertainty"],
    opportunities: ["Banking partnerships", "Cross-border payment use case", "Fast settlement times"],
    videoTitle: "XRP & Ripple: Banking on Blockchain",
    videoDescription: "How Ripple is working with banks for cross-border payments and financial infrastructure",
  },
  {
    id: "chainlink",
    name: "Chainlink",
    symbol: "LINK",
    rating: 8.1,
    price: "$14.50",
    marketCap: "$8.5B",
    change24h: 4.2,
    category: "Oracle Network",
    description: "Decentralized oracle network providing real-world data to smart contracts on various blockchains.",
    technology: "Decentralized oracle network. Provides price feeds, randomness, and external data to smart contracts.",
    team: "Founded by Sergey Nazarov. Strong partnerships with major blockchain projects and enterprises.",
    adoption: "De facto standard for DeFi price feeds. Integrated with most major blockchains. CCIP for cross-chain communication.",
    risks: ["Token utility concerns", "Competition from other oracles", "Complexity of network"],
    opportunities: ["Growing DeFi dependence on oracles", "Cross-chain interoperability", "Enterprise adoption"],
    videoTitle: "Chainlink Oracles: Bringing Real-World Data to Blockchain",
    videoDescription: "Learn how Chainlink connects smart contracts to external data and powers DeFi",
    isPremium: true,
  },
  {
    id: "avalanche",
    name: "Avalanche",
    symbol: "AVAX",
    rating: 7.7,
    price: "$35",
    marketCap: "$14B",
    change24h: 3.5,
    category: "Smart Contract Platform",
    description: "Platform for launching decentralized applications and enterprise blockchain deployments with near-instant finality.",
    technology: "Uses Avalanche consensus protocol. Three built-in blockchains: X-Chain, C-Chain, and P-Chain for different functions.",
    team: "Founded by Emin Gün Sirer (Cornell professor). Developed by Ava Labs.",
    adoption: "Growing subnet ecosystem. DeFi applications. Enterprise blockchain solutions.",
    risks: ["High token inflation", "Ecosystem smaller than Ethereum", "Subnet adoption challenges"],
    opportunities: ["Subnet architecture", "Fast finality", "EVM compatibility"],
    videoTitle: "Avalanche: Subnets & Enterprise Blockchain",
    videoDescription: "Discover Avalanche's unique subnet architecture and how it enables custom blockchains",
    isPremium: true,
  },
];
```

### `/src/app/pages/Home.tsx`
```tsx
import { Link } from "react-router";
import { Button } from "../components/ui/button";
import { Card } from "../components/ui/card";
import { VideoPlayer } from "../components/VideoPlayer";
import { TrendingUp, GraduationCap, Wallet, Star } from "lucide-react";

export function Home() {
  return (
    <div className="space-y-16">
      {/* Hero Section */}
      <section className="text-center space-y-6 py-12">
        <h1 className="text-5xl md:text-7xl font-bold bg-gradient-to-r from-neon-cyan via-neon-green to-neon-magenta bg-clip-text text-transparent">
          Welcome to Crypto 101
        </h1>
        <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
          Your gateway to understanding cryptocurrency. Learn, analyze, and build your crypto knowledge with expert ratings and education.
        </p>
        <div className="flex gap-4 justify-center">
          <Link to="/ratings">
            <Button className="bg-neon-green text-black hover:bg-neon-green/90">
              Explore Ratings
            </Button>
          </Link>
          <Link to="/classroom">
            <Button variant="outline" className="border-neon-cyan text-neon-cyan hover:bg-neon-cyan/10">
              Start Learning
            </Button>
          </Link>
        </div>
      </section>

      {/* Welcome Video Section */}
      <section className="max-w-4xl mx-auto space-y-4">
        <div className="text-center space-y-2">
          <h2 className="text-3xl font-bold">Welcome Video</h2>
          <p className="text-muted-foreground">
            Get started with a quick introduction to our platform and what we offer
          </p>
        </div>
        <VideoPlayer 
          title="Welcome to [Company Name] - Your Crypto Journey Starts Here"
          description="Learn about our mission, features, and how we can help you navigate the crypto space"
        />
      </section>

      {/* Features Grid */}
      <section className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Link to="/ratings">
          <Card className="p-6 hover:border-neon-green transition-colors cursor-pointer h-full">
            <Star className="w-12 h-12 text-neon-green mb-4" />
            <h3 className="text-xl mb-2">Crypto Ratings</h3>
            <p className="text-muted-foreground">
              Expert analysis and ratings for top cryptocurrencies
            </p>
          </Card>
        </Link>

        <Link to="/classroom">
          <Card className="p-6 hover:border-neon-cyan transition-colors cursor-pointer h-full">
            <GraduationCap className="w-12 h-12 text-neon-cyan mb-4" />
            <h3 className="text-xl mb-2">Classroom</h3>
            <p className="text-muted-foreground">
              Learn crypto fundamentals from beginner to advanced
            </p>
          </Card>
        </Link>

        <Link to="/portfolio">
          <Card className="p-6 hover:border-neon-magenta transition-colors cursor-pointer h-full">
            <Wallet className="w-12 h-12 text-neon-magenta mb-4" />
            <h3 className="text-xl mb-2">Portfolio</h3>
            <p className="text-muted-foreground">
              Build and track your custom crypto portfolio
            </p>
          </Card>
        </Link>

        <Card className="p-6 border-neon-yellow h-full">
          <TrendingUp className="w-12 h-12 text-neon-yellow mb-4" />
          <h3 className="text-xl mb-2">Premium Access</h3>
          <p className="text-muted-foreground">
            Unlock advanced features and exclusive content
          </p>
        </Card>
      </section>

      {/* Stats Section */}
      <section className="grid md:grid-cols-3 gap-8 py-12">
        <div className="text-center">
          <div className="text-4xl font-bold text-neon-cyan mb-2">100+</div>
          <div className="text-muted-foreground">Cryptocurrencies Rated</div>
        </div>
        <div className="text-center">
          <div className="text-4xl font-bold text-neon-green mb-2">50+</div>
          <div className="text-muted-foreground">Learning Modules</div>
        </div>
        <div className="text-center">
          <div className="text-4xl font-bold text-neon-magenta mb-2">10K+</div>
          <div className="text-muted-foreground">Active Users</div>
        </div>
      </section>
    </div>
  );
}
```

### `/src/app/pages/CryptoRatings.tsx`
```tsx
import { Link } from "react-router";
import { Card } from "../components/ui/card";
import { Badge } from "../components/ui/badge";
import { Input } from "../components/ui/input";
import { Lock, TrendingUp, TrendingDown } from "lucide-react";
import { cryptoRatings } from "../data/cryptoData";
import { useState } from "react";

export function CryptoRatings() {
  const [search, setSearch] = useState("");

  const filteredCryptos = cryptoRatings.filter(
    (crypto) =>
      crypto.name.toLowerCase().includes(search.toLowerCase()) ||
      crypto.symbol.toLowerCase().includes(search.toLowerCase())
  );

  const getRatingColor = (rating: number) => {
    if (rating >= 8.5) return "text-neon-green";
    if (rating >= 7.5) return "text-neon-cyan";
    if (rating >= 6.5) return "text-neon-yellow";
    return "text-accent";
  };

  return (
    <div className="space-y-8">
      <div className="space-y-4">
        <h1 className="text-4xl font-bold">Crypto Rating System</h1>
        <p className="text-muted-foreground">
          Expert analysis and ratings for top cryptocurrencies based on technology, adoption, team, and market potential.
        </p>
        <Input
          type="search"
          placeholder="Search cryptocurrencies..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          className="max-w-md bg-input-background"
        />
      </div>

      <div className="grid gap-4">
        {filteredCryptos.map((crypto) => (
          <Link key={crypto.id} to={`/crypto/${crypto.id}`}>
            <Card className="p-6 hover:border-neon-green transition-colors cursor-pointer relative overflow-hidden">
              {crypto.isPremium && (
                <div className="absolute top-4 right-4">
                  <Badge className="bg-neon-yellow/20 text-neon-yellow border-neon-yellow">
                    <Lock className="w-3 h-3 mr-1" />
                    Premium
                  </Badge>
                </div>
              )}
              
              <div className="flex flex-col md:flex-row md:items-center gap-4">
                <div className="flex items-center gap-4 flex-1">
                  <div className="w-12 h-12 rounded-full bg-gradient-to-br from-neon-cyan to-neon-magenta flex items-center justify-center">
                    <span className="text-xl font-bold">{crypto.symbol.charAt(0)}</span>
                  </div>
                  
                  <div className="flex-1">
                    <div className="flex items-center gap-2">
                      <h3 className="text-xl">{crypto.name}</h3>
                      <span className="text-muted-foreground">({crypto.symbol})</span>
                    </div>
                    <p className="text-sm text-muted-foreground">{crypto.category}</p>
                  </div>
                </div>

                <div className="flex items-center gap-8">
                  <div>
                    <div className="text-sm text-muted-foreground">Price</div>
                    <div className="text-lg">{crypto.price}</div>
                  </div>

                  <div>
                    <div className="text-sm text-muted-foreground">24h Change</div>
                    <div className={`text-lg flex items-center gap-1 ${crypto.change24h >= 0 ? 'text-neon-green' : 'text-accent'}`}>
                      {crypto.change24h >= 0 ? (
                        <TrendingUp className="w-4 h-4" />
                      ) : (
                        <TrendingDown className="w-4 h-4" />
                      )}
                      {crypto.change24h >= 0 ? '+' : ''}{crypto.change24h}%
                    </div>
                  </div>

                  <div>
                    <div className="text-sm text-muted-foreground">Market Cap</div>
                    <div className="text-lg">{crypto.marketCap}</div>
                  </div>

                  <div className="text-center">
                    <div className="text-sm text-muted-foreground mb-1">Rating</div>
                    <div className={`text-3xl font-bold ${getRatingColor(crypto.rating)}`}>
                      {crypto.rating}
                    </div>
                  </div>
                </div>
              </div>
            </Card>
          </Link>
        ))}
      </div>
    </div>
  );
}
```

### `/src/app/pages/CryptoDetail.tsx`
```tsx
import { useParams, Link } from "react-router";
import { Card } from "../components/ui/card";
import { Badge } from "../components/ui/badge";
import { Button } from "../components/ui/button";
import { VideoPlayer } from "../components/VideoPlayer";
import { ArrowLeft, TrendingUp, TrendingDown, Lock, AlertTriangle, Sparkles } from "lucide-react";
import { cryptoRatings } from "../data/cryptoData";

export function CryptoDetail() {
  const { id } = useParams();
  const crypto = cryptoRatings.find((c) => c.id === id);

  if (!crypto) {
    return (
      <div className="text-center py-12">
        <h2 className="text-2xl mb-4">Cryptocurrency not found</h2>
        <Link to="/ratings">
          <Button>Back to Ratings</Button>
        </Link>
      </div>
    );
  }

  const getRatingColor = (rating: number) => {
    if (rating >= 8.5) return "text-neon-green";
    if (rating >= 7.5) return "text-neon-cyan";
    if (rating >= 6.5) return "text-neon-yellow";
    return "text-accent";
  };

  return (
    <div className="space-y-8 max-w-5xl mx-auto">
      <Link to="/ratings">
        <Button variant="ghost" className="gap-2">
          <ArrowLeft className="w-4 h-4" />
          Back to Ratings
        </Button>
      </Link>

      {/* Header */}
      <div className="flex items-start justify-between">
        <div className="flex items-center gap-4">
          <div className="w-20 h-20 rounded-full bg-gradient-to-br from-neon-cyan to-neon-magenta flex items-center justify-center">
            <span className="text-3xl font-bold">{crypto.symbol.charAt(0)}</span>
          </div>
          <div>
            <div className="flex items-center gap-3 mb-2">
              <h1 className="text-4xl font-bold">{crypto.name}</h1>
              <span className="text-2xl text-muted-foreground">({crypto.symbol})</span>
              {crypto.isPremium && (
                <Badge className="bg-neon-yellow/20 text-neon-yellow border-neon-yellow">
                  <Lock className="w-3 h-3 mr-1" />
                  Premium
                </Badge>
              )}
            </div>
            <Badge variant="outline" className="border-neon-cyan text-neon-cyan">
              {crypto.category}
            </Badge>
          </div>
        </div>
        
        <div className="text-right">
          <div className="text-sm text-muted-foreground mb-1">Overall Rating</div>
          <div className={`text-5xl font-bold ${getRatingColor(crypto.rating)}`}>
            {crypto.rating}
          </div>
        </div>
      </div>

      {/* Price Info */}
      <div className="grid grid-cols-3 gap-4">
        <Card className="p-6">
          <div className="text-sm text-muted-foreground mb-2">Current Price</div>
          <div className="text-3xl font-bold">{crypto.price}</div>
        </Card>
        <Card className="p-6">
          <div className="text-sm text-muted-foreground mb-2">24h Change</div>
          <div className={`text-3xl font-bold flex items-center gap-2 ${crypto.change24h >= 0 ? 'text-neon-green' : 'text-accent'}`}>
            {crypto.change24h >= 0 ? (
              <TrendingUp className="w-6 h-6" />
            ) : (
              <TrendingDown className="w-6 h-6" />
            )}
            {crypto.change24h >= 0 ? '+' : ''}{crypto.change24h}%
          </div>
        </Card>
        <Card className="p-6">
          <div className="text-sm text-muted-foreground mb-2">Market Cap</div>
          <div className="text-3xl font-bold">{crypto.marketCap}</div>
        </Card>
      </div>

      {/* Description */}
      <Card className="p-6">
        <h2 className="text-2xl mb-4">Overview</h2>
        <p className="text-muted-foreground leading-relaxed">{crypto.description}</p>
      </Card>

      {/* Video Section */}
      {crypto.videoTitle && (
        <div className="space-y-3">
          <h2 className="text-2xl">Video Analysis</h2>
          <VideoPlayer 
            title={crypto.videoTitle}
            description={crypto.videoDescription}
            videoUrl={crypto.videoUrl}
          />
        </div>
      )}

      {/* Technology */}
      <Card className="p-6">
        <h2 className="text-2xl mb-4 flex items-center gap-2">
          <span className="text-neon-cyan">●</span> Technology
        </h2>
        <p className="text-muted-foreground leading-relaxed">{crypto.technology}</p>
      </Card>

      {/* Team & Development */}
      <Card className="p-6">
        <h2 className="text-2xl mb-4 flex items-center gap-2">
          <span className="text-neon-green">●</span> Team & Development
        </h2>
        <p className="text-muted-foreground leading-relaxed">{crypto.team}</p>
      </Card>

      {/* Adoption */}
      <Card className="p-6">
        <h2 className="text-2xl mb-4 flex items-center gap-2">
          <span className="text-neon-magenta">●</span> Adoption & Use Cases
        </h2>
        <p className="text-muted-foreground leading-relaxed">{crypto.adoption}</p>
      </Card>

      {/* Risks & Opportunities */}
      <div className="grid md:grid-cols-2 gap-6">
        <Card className="p-6 border-accent/50">
          <h2 className="text-2xl mb-4 flex items-center gap-2">
            <AlertTriangle className="w-6 h-6 text-accent" />
            Risks
          </h2>
          <ul className="space-y-2">
            {crypto.risks.map((risk, index) => (
              <li key={index} className="flex items-start gap-2">
                <span className="text-accent mt-1">•</span>
                <span className="text-muted-foreground">{risk}</span>
              </li>
            ))}
          </ul>
        </Card>

        <Card className="p-6 border-neon-green/50">
          <h2 className="text-2xl mb-4 flex items-center gap-2">
            <Sparkles className="w-6 h-6 text-neon-green" />
            Opportunities
          </h2>
          <ul className="space-y-2">
            {crypto.opportunities.map((opportunity, index) => (
              <li key={index} className="flex items-start gap-2">
                <span className="text-neon-green mt-1">•</span>
                <span className="text-muted-foreground">{opportunity}</span>
              </li>
            ))}
          </ul>
        </Card>
      </div>
    </div>
  );
}
```

### `/src/app/pages/Classroom.tsx`
```tsx
import { Card } from "../components/ui/card";
import { Badge } from "../components/ui/badge";
import { Button } from "../components/ui/button";
import { Lock, BookOpen, Video, FileText, CheckCircle2 } from "lucide-react";

interface Course {
  id: string;
  title: string;
  description: string;
  level: "Beginner" | "Intermediate" | "Advanced";
  lessons: number;
  duration: string;
  isPremium?: boolean;
  progress?: number;
}

const courses: Course[] = [
  {
    id: "1",
    title: "Cryptocurrency Fundamentals",
    description: "Learn the basics of blockchain technology, cryptocurrencies, and how digital assets work.",
    level: "Beginner",
    lessons: 8,
    duration: "2 hours",
    progress: 75,
  },
  {
    id: "2",
    title: "Bitcoin Deep Dive",
    description: "Comprehensive exploration of Bitcoin's technology, history, and role in the financial system.",
    level: "Beginner",
    lessons: 10,
    duration: "3 hours",
    progress: 30,
  },
  {
    id: "3",
    title: "Smart Contracts & DeFi",
    description: "Understanding smart contracts, decentralized finance, and the Ethereum ecosystem.",
    level: "Intermediate",
    lessons: 12,
    duration: "4 hours",
    isPremium: true,
  },
  {
    id: "4",
    title: "Technical Analysis for Crypto",
    description: "Learn to read charts, identify patterns, and make informed trading decisions.",
    level: "Intermediate",
    lessons: 15,
    duration: "5 hours",
    isPremium: true,
  },
  {
    id: "5",
    title: "Blockchain Development Basics",
    description: "Introduction to building on blockchain platforms and creating decentralized applications.",
    level: "Advanced",
    lessons: 20,
    duration: "8 hours",
    isPremium: true,
  },
  {
    id: "6",
    title: "Advanced Trading Strategies",
    description: "Professional trading techniques, risk management, and portfolio optimization.",
    level: "Advanced",
    lessons: 18,
    duration: "6 hours",
    isPremium: true,
  },
  {
    id: "7",
    title: "Crypto Security & Wallets",
    description: "Best practices for securing your crypto assets and understanding different wallet types.",
    level: "Beginner",
    lessons: 6,
    duration: "2 hours",
    progress: 0,
  },
  {
    id: "8",
    title: "NFTs & Digital Collectibles",
    description: "Explore the world of NFTs, digital art, and the future of digital ownership.",
    level: "Intermediate",
    lessons: 10,
    duration: "3 hours",
    isPremium: true,
  },
];

export function Classroom() {
  const getLevelColor = (level: string) => {
    switch (level) {
      case "Beginner":
        return "border-neon-green text-neon-green";
      case "Intermediate":
        return "border-neon-cyan text-neon-cyan";
      case "Advanced":
        return "border-neon-magenta text-neon-magenta";
      default:
        return "";
    }
  };

  return (
    <div className="space-y-8">
      <div className="space-y-4">
        <h1 className="text-4xl font-bold">Crypto Classroom</h1>
        <p className="text-muted-foreground">
          Master cryptocurrency from fundamentals to advanced concepts with our comprehensive courses.
        </p>
      </div>

      {/* Learning Path Stats */}
      <div className="grid md:grid-cols-4 gap-4">
        <Card className="p-6">
          <BookOpen className="w-8 h-8 text-neon-green mb-2" />
          <div className="text-2xl font-bold">50+</div>
          <div className="text-sm text-muted-foreground">Total Lessons</div>
        </Card>
        <Card className="p-6">
          <Video className="w-8 h-8 text-neon-cyan mb-2" />
          <div className="text-2xl font-bold">30+</div>
          <div className="text-sm text-muted-foreground">Video Tutorials</div>
        </Card>
        <Card className="p-6">
          <FileText className="w-8 h-8 text-neon-yellow mb-2" />
          <div className="text-2xl font-bold">100+</div>
          <div className="text-sm text-muted-foreground">Articles & Guides</div>
        </Card>
        <Card className="p-6">
          <CheckCircle2 className="w-8 h-8 text-neon-magenta mb-2" />
          <div className="text-2xl font-bold">2/8</div>
          <div className="text-sm text-muted-foreground">Courses Completed</div>
        </Card>
      </div>

      {/* Courses Grid */}
      <div className="grid md:grid-cols-2 gap-6">
        {courses.map((course) => (
          <Card
            key={course.id}
            className={`p-6 relative ${course.isPremium ? 'border-neon-yellow/30' : ''}`}
          >
            {course.isPremium && (
              <div className="absolute top-4 right-4">
                <Badge className="bg-neon-yellow/20 text-neon-yellow border-neon-yellow">
                  <Lock className="w-3 h-3 mr-1" />
                  Premium
                </Badge>
              </div>
            )}

            <div className="space-y-4">
              <div>
                <h3 className="text-xl mb-2">{course.title}</h3>
                <p className="text-sm text-muted-foreground">{course.description}</p>
              </div>

              <div className="flex items-center gap-2">
                <Badge variant="outline" className={getLevelColor(course.level)}>
                  {course.level}
                </Badge>
                <span className="text-sm text-muted-foreground">
                  {course.lessons} lessons • {course.duration}
                </span>
              </div>

              {course.progress !== undefined && (
                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span className="text-muted-foreground">Progress</span>
                    <span className="text-neon-green">{course.progress}%</span>
                  </div>
                  <div className="h-2 bg-muted rounded-full overflow-hidden">
                    <div
                      className="h-full bg-neon-green transition-all"
                      style={{ width: `${course.progress}%` }}
                    />
                  </div>
                </div>
              )}

              <Button
                className={
                  course.isPremium
                    ? "w-full bg-gradient-to-r from-neon-yellow/20 to-neon-magenta/20 border border-neon-yellow hover:opacity-90"
                    : course.progress !== undefined && course.progress > 0
                    ? "w-full bg-neon-green text-black hover:bg-neon-green/90"
                    : "w-full"
                }
              >
                {course.progress !== undefined && course.progress > 0
                  ? "Continue Learning"
                  : course.isPremium
                  ? "Unlock with Premium"
                  : "Start Course"}
              </Button>
            </div>
          </Card>
        ))}
      </div>
    </div>
  );
}
```

### `/src/app/pages/Portfolio.tsx`
```tsx
import { Card } from "../components/ui/card";
import { Button } from "../components/ui/button";
import { Badge } from "../components/ui/badge";
import { Plus, TrendingUp, TrendingDown, Wallet, PieChart, DollarSign } from "lucide-react";
import { useState } from "react";

interface PortfolioItem {
  id: string;
  crypto: string;
  symbol: string;
  amount: number;
  avgPrice: number;
  currentPrice: number;
  value: number;
  change: number;
  changePercent: number;
}

export function Portfolio() {
  const [portfolioItems] = useState<PortfolioItem[]>([
    {
      id: "1",
      crypto: "Bitcoin",
      symbol: "BTC",
      amount: 0.5,
      avgPrice: 42000,
      currentPrice: 45230,
      value: 22615,
      change: 1615,
      changePercent: 7.69,
    },
    {
      id: "2",
      crypto: "Ethereum",
      symbol: "ETH",
      amount: 5,
      avgPrice: 2200,
      currentPrice: 2420,
      value: 12100,
      change: 1100,
      changePercent: 10.0,
    },
    {
      id: "3",
      crypto: "Cardano",
      symbol: "ADA",
      amount: 1000,
      avgPrice: 0.55,
      currentPrice: 0.52,
      value: 520,
      change: -30,
      changePercent: -5.45,
    },
  ]);

  const totalValue = portfolioItems.reduce((sum, item) => sum + item.value, 0);
  const totalChange = portfolioItems.reduce((sum, item) => sum + item.change, 0);
  const totalChangePercent = (totalChange / (totalValue - totalChange)) * 100;

  return (
    <div className="space-y-8">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-4xl font-bold mb-2">My Portfolio</h1>
          <p className="text-muted-foreground">
            Track and manage your cryptocurrency investments
          </p>
        </div>
        <Button className="bg-neon-green text-black hover:bg-neon-green/90">
          <Plus className="w-4 h-4 mr-2" />
          Add Asset
        </Button>
      </div>

      {/* Portfolio Summary */}
      <div className="grid md:grid-cols-4 gap-4">
        <Card className="p-6 border-neon-green/50">
          <div className="flex items-center justify-between mb-2">
            <Wallet className="w-8 h-8 text-neon-green" />
          </div>
          <div className="text-sm text-muted-foreground mb-1">Total Value</div>
          <div className="text-3xl font-bold">${totalValue.toLocaleString()}</div>
        </Card>

        <Card className="p-6">
          <div className="flex items-center justify-between mb-2">
            {totalChange >= 0 ? (
              <TrendingUp className="w-8 h-8 text-neon-green" />
            ) : (
              <TrendingDown className="w-8 h-8 text-accent" />
            )}
          </div>
          <div className="text-sm text-muted-foreground mb-1">Total P&L</div>
          <div className={`text-3xl font-bold ${totalChange >= 0 ? 'text-neon-green' : 'text-accent'}`}>
            {totalChange >= 0 ? '+' : ''}${totalChange.toLocaleString()}
          </div>
        </Card>

        <Card className="p-6">
          <div className="flex items-center justify-between mb-2">
            <DollarSign className="w-8 h-8 text-neon-cyan" />
          </div>
          <div className="text-sm text-muted-foreground mb-1">Total Return</div>
          <div className={`text-3xl font-bold ${totalChangePercent >= 0 ? 'text-neon-green' : 'text-accent'}`}>
            {totalChangePercent >= 0 ? '+' : ''}{totalChangePercent.toFixed(2)}%
          </div>
        </Card>

        <Card className="p-6">
          <div className="flex items-center justify-between mb-2">
            <PieChart className="w-8 h-8 text-neon-magenta" />
          </div>
          <div className="text-sm text-muted-foreground mb-1">Holdings</div>
          <div className="text-3xl font-bold">{portfolioItems.length}</div>
        </Card>
      </div>

      {/* Portfolio Holdings */}
      <Card className="p-6">
        <h2 className="text-2xl mb-6">Holdings</h2>
        <div className="space-y-4">
          {portfolioItems.map((item) => (
            <div
              key={item.id}
              className="flex items-center justify-between p-4 rounded-lg bg-muted/30 hover:bg-muted/50 transition-colors"
            >
              <div className="flex items-center gap-4 flex-1">
                <div className="w-12 h-12 rounded-full bg-gradient-to-br from-neon-cyan to-neon-magenta flex items-center justify-center">
                  <span className="font-bold">{item.symbol.charAt(0)}</span>
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <span className="font-medium">{item.crypto}</span>
                    <span className="text-muted-foreground text-sm">({item.symbol})</span>
                  </div>
                  <div className="text-sm text-muted-foreground">
                    {item.amount} {item.symbol}
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-4 gap-8 text-right">
                <div>
                  <div className="text-sm text-muted-foreground mb-1">Avg Price</div>
                  <div>${item.avgPrice.toLocaleString()}</div>
                </div>

                <div>
                  <div className="text-sm text-muted-foreground mb-1">Current Price</div>
                  <div>${item.currentPrice.toLocaleString()}</div>
                </div>

                <div>
                  <div className="text-sm text-muted-foreground mb-1">Value</div>
                  <div className="font-medium">${item.value.toLocaleString()}</div>
                </div>

                <div>
                  <div className="text-sm text-muted-foreground mb-1">P&L</div>
                  <div className={`font-medium ${item.change >= 0 ? 'text-neon-green' : 'text-accent'}`}>
                    {item.change >= 0 ? '+' : ''}${item.change.toLocaleString()}
                    <Badge
                      variant="outline"
                      className={`ml-2 ${item.changePercent >= 0 ? 'border-neon-green text-neon-green' : 'border-accent text-accent'}`}
                    >
                      {item.changePercent >= 0 ? '+' : ''}{item.changePercent.toFixed(2)}%
                    </Badge>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </Card>

      {/* Portfolio Allocation */}
      <Card className="p-6">
        <h2 className="text-2xl mb-6">Portfolio Allocation</h2>
        <div className="space-y-4">
          {portfolioItems.map((item) => {
            const percentage = (item.value / totalValue) * 100;
            return (
              <div key={item.id}>
                <div className="flex justify-between mb-2">
                  <span>{item.crypto}</span>
                  <span className="text-muted-foreground">{percentage.toFixed(2)}%</span>
                </div>
                <div className="h-3 bg-muted rounded-full overflow-hidden">
                  <div
                    className="h-full bg-gradient-to-r from-neon-cyan to-neon-magenta"
                    style={{ width: `${percentage}%` }}
                  />
                </div>
              </div>
            );
          })}
        </div>
      </Card>
    </div>
  );
}
```

### `/src/app/pages/About.tsx`
```tsx
import { Card } from "../components/ui/card";
import { Target, Users, Zap, Shield } from "lucide-react";

export function About() {
  return (
    <div className="space-y-12 max-w-4xl mx-auto">
      <div className="text-center space-y-4">
        <h1 className="text-5xl font-bold bg-gradient-to-r from-neon-cyan via-neon-green to-neon-magenta bg-clip-text text-transparent">
          About [Company Name]
        </h1>
        <p className="text-xl text-muted-foreground">
          Empowering investors with knowledge and insights in the cryptocurrency space
        </p>
      </div>

      {/* Mission Statement */}
      <Card className="p-8 border-neon-green/50">
        <h2 className="text-3xl mb-4">Our Mission</h2>
        <p className="text-lg text-muted-foreground leading-relaxed">
          We believe that cryptocurrency represents the future of finance, but navigating this complex landscape can be overwhelming. Our mission is to democratize crypto education and provide transparent, unbiased ratings and analysis to help everyone make informed investment decisions.
        </p>
      </Card>

      {/* Core Values */}
      <div className="grid md:grid-cols-2 gap-6">
        <Card className="p-6">
          <Target className="w-12 h-12 text-neon-green mb-4" />
          <h3 className="text-2xl mb-3">Transparency</h3>
          <p className="text-muted-foreground">
            Our rating methodology is clear and consistent. We provide detailed analysis so you understand exactly how we evaluate each cryptocurrency.
          </p>
        </Card>

        <Card className="p-6">
          <Users className="w-12 h-12 text-neon-cyan mb-4" />
          <h3 className="text-2xl mb-3">Education First</h3>
          <p className="text-muted-foreground">
            We prioritize teaching over selling. Our comprehensive classroom helps you build real knowledge and confidence in the crypto space.
          </p>
        </Card>

        <Card className="p-6">
          <Zap className="w-12 h-12 text-neon-yellow mb-4" />
          <h3 className="text-2xl mb-3">Data-Driven</h3>
          <p className="text-muted-foreground">
            Every rating is backed by thorough research, technical analysis, and real-world adoption metrics. No hype, just facts.
          </p>
        </Card>

        <Card className="p-6">
          <Shield className="w-12 h-12 text-neon-magenta mb-4" />
          <h3 className="text-2xl mb-3">Community Focus</h3>
          <p className="text-muted-foreground">
            We're building a community of informed crypto enthusiasts who support each other's learning journey.
          </p>
        </Card>
      </div>

      {/* What We Offer */}
      <Card className="p-8">
        <h2 className="text-3xl mb-6">What We Offer</h2>
        <div className="space-y-6">
          <div>
            <h3 className="text-xl mb-2 text-neon-green">Comprehensive Ratings</h3>
            <p className="text-muted-foreground">
              In-depth analysis of cryptocurrencies covering technology, team, adoption, and market potential. Our ratings help you cut through the noise.
            </p>
          </div>
          <div>
            <h3 className="text-xl mb-2 text-neon-cyan">Expert Education</h3>
            <p className="text-muted-foreground">
              From blockchain basics to advanced trading strategies, our classroom offers structured learning paths for all experience levels.
            </p>
          </div>
          <div>
            <h3 className="text-xl mb-2 text-neon-magenta">Portfolio Tools</h3>
            <p className="text-muted-foreground">
              Track your investments, analyze performance, and make better decisions with our custom portfolio management tools.
            </p>
          </div>
          <div>
            <h3 className="text-xl mb-2 text-neon-yellow">Premium Insights</h3>
            <p className="text-muted-foreground">
              Premium members get access to exclusive research, advanced analytics, and early access to new ratings and courses.
            </p>
          </div>
        </div>
      </Card>

      {/* Team Placeholder */}
      <Card className="p-8 text-center">
        <h2 className="text-3xl mb-4">Our Team</h2>
        <p className="text-muted-foreground mb-6">
          We're a diverse team of blockchain experts, financial analysts, and educators passionate about cryptocurrency and its potential to transform finance.
        </p>
        <div className="grid md:grid-cols-4 gap-4 mt-8">
          {[1, 2, 3, 4].map((i) => (
            <div key={i} className="space-y-2">
              <div className="w-24 h-24 mx-auto rounded-full bg-gradient-to-br from-neon-cyan to-neon-magenta" />
              <div className="text-muted-foreground text-sm">Team Member</div>
              <div className="text-xs text-muted-foreground">Role</div>
            </div>
          ))}
        </div>
      </Card>

      {/* Contact CTA */}
      <Card className="p-8 text-center bg-gradient-to-r from-neon-green/10 to-neon-cyan/10 border-neon-green/50">
        <h2 className="text-3xl mb-4">Join Our Community</h2>
        <p className="text-muted-foreground mb-6">
          Ready to start your crypto journey? Join thousands of learners and investors making smarter decisions.
        </p>
        <div className="text-neon-green">contact@[company].com</div>
      </Card>
    </div>
  );
}
```

### `/src/app/pages/Profile.tsx`
```tsx
import { Card } from "../components/ui/card";
import { Button } from "../components/ui/button";
import { Input } from "../components/ui/input";
import { Label } from "../components/ui/label";
import { Badge } from "../components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "../components/ui/tabs";
import { 
  User, 
  Mail, 
  Crown, 
  Settings, 
  Bell, 
  Shield,
  BookOpen,
  TrendingUp,
  Award
} from "lucide-react";
import { useState } from "react";

export function Profile() {
  const [isPremium] = useState(false);

  return (
    <div className="space-y-8 max-w-5xl mx-auto">
      {/* Profile Header */}
      <div className="flex items-start justify-between">
        <div className="flex items-center gap-6">
          <div className="w-24 h-24 rounded-full bg-gradient-to-br from-neon-cyan to-neon-magenta flex items-center justify-center">
            <User className="w-12 h-12" />
          </div>
          <div>
            <h1 className="text-3xl font-bold mb-2">User Profile</h1>
            <div className="flex items-center gap-3">
              <Badge variant="outline" className="border-neon-green text-neon-green">
                Free Member
              </Badge>
              <span className="text-muted-foreground">Member since Feb 2026</span>
            </div>
          </div>
        </div>

        {!isPremium && (
          <Button className="bg-gradient-to-r from-neon-magenta to-neon-cyan text-white hover:opacity-90">
            <Crown className="w-4 h-4 mr-2" />
            Upgrade to Premium
          </Button>
        )}
      </div>

      <Tabs defaultValue="overview" className="w-full">
        <TabsList className="grid w-full grid-cols-4 mb-8">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="settings">Settings</TabsTrigger>
          <TabsTrigger value="activity">Activity</TabsTrigger>
          <TabsTrigger value="preferences">Preferences</TabsTrigger>
        </TabsList>

        {/* Overview Tab */}
        <TabsContent value="overview" className="space-y-6">
          <div className="grid md:grid-cols-3 gap-6">
            <Card className="p-6">
              <BookOpen className="w-8 h-8 text-neon-green mb-3" />
              <div className="text-2xl font-bold mb-1">12</div>
              <div className="text-sm text-muted-foreground">Courses Started</div>
            </Card>

            <Card className="p-6">
              <Award className="w-8 h-8 text-neon-cyan mb-3" />
              <div className="text-2xl font-bold mb-1">3</div>
              <div className="text-sm text-muted-foreground">Courses Completed</div>
            </Card>

            <Card className="p-6">
              <TrendingUp className="w-8 h-8 text-neon-magenta mb-3" />
              <div className="text-2xl font-bold mb-1">5</div>
              <div className="text-sm text-muted-foreground">Portfolio Holdings</div>
            </Card>
          </div>

          {/* Learning Progress */}
          <Card className="p-6">
            <h2 className="text-2xl mb-6">Learning Progress</h2>
            <div className="space-y-4">
              <div>
                <div className="flex justify-between mb-2">
                  <span>Cryptocurrency Fundamentals</span>
                  <span className="text-neon-green">75%</span>
                </div>
                <div className="h-2 bg-muted rounded-full overflow-hidden">
                  <div className="h-full bg-neon-green" style={{ width: "75%" }} />
                </div>
              </div>
              <div>
                <div className="flex justify-between mb-2">
                  <span>Bitcoin Deep Dive</span>
                  <span className="text-neon-cyan">30%</span>
                </div>
                <div className="h-2 bg-muted rounded-full overflow-hidden">
                  <div className="h-full bg-neon-cyan" style={{ width: "30%" }} />
                </div>
              </div>
              <div>
                <div className="flex justify-between mb-2">
                  <span>Crypto Security & Wallets</span>
                  <span className="text-muted-foreground">0%</span>
                </div>
                <div className="h-2 bg-muted rounded-full overflow-hidden">
                  <div className="h-full bg-muted" style={{ width: "0%" }} />
                </div>
              </div>
            </div>
          </Card>

          {/* Recent Activity */}
          <Card className="p-6">
            <h2 className="text-2xl mb-6">Recent Activity</h2>
            <div className="space-y-4">
              {[
                { action: "Completed lesson", course: "Bitcoin Fundamentals", time: "2 hours ago" },
                { action: "Added to portfolio", course: "Ethereum (ETH)", time: "1 day ago" },
                { action: "Started course", course: "Smart Contracts & DeFi", time: "3 days ago" },
                { action: "Viewed rating", course: "Cardano (ADA)", time: "1 week ago" },
              ].map((activity, index) => (
                <div key={index} className="flex items-center justify-between py-2 border-b border-border last:border-0">
                  <div>
                    <div className="font-medium">{activity.action}</div>
                    <div className="text-sm text-muted-foreground">{activity.course}</div>
                  </div>
                  <div className="text-sm text-muted-foreground">{activity.time}</div>
                </div>
              ))}
            </div>
          </Card>
        </TabsContent>

        {/* Settings Tab */}
        <TabsContent value="settings" className="space-y-6">
          <Card className="p-6">
            <h2 className="text-2xl mb-6 flex items-center gap-2">
              <User className="w-6 h-6" />
              Profile Information
            </h2>
            <div className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="name">Full Name</Label>
                <Input id="name" defaultValue="John Doe" />
              </div>
              <div className="space-y-2">
                <Label htmlFor="email">Email</Label>
                <Input id="email" type="email" defaultValue="john@example.com" />
              </div>
              <div className="space-y-2">
                <Label htmlFor="username">Username</Label>
                <Input id="username" defaultValue="johndoe" />
              </div>
              <Button className="bg-neon-green text-black hover:bg-neon-green/90">
                Save Changes
              </Button>
            </div>
          </Card>

          <Card className="p-6">
            <h2 className="text-2xl mb-6 flex items-center gap-2">
              <Shield className="w-6 h-6" />
              Security
            </h2>
            <div className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="current-password">Current Password</Label>
                <Input id="current-password" type="password" />
              </div>
              <div className="space-y-2">
                <Label htmlFor="new-password">New Password</Label>
                <Input id="new-password" type="password" />
              </div>
              <div className="space-y-2">
                <Label htmlFor="confirm-password">Confirm New Password</Label>
                <Input id="confirm-password" type="password" />
              </div>
              <Button variant="outline">Update Password</Button>
            </div>
          </Card>
        </TabsContent>

        {/* Activity Tab */}
        <TabsContent value="activity" className="space-y-6">
          <Card className="p-6">
            <h2 className="text-2xl mb-6">Activity History</h2>
            <div className="space-y-4">
              {[
                { date: "Feb 17, 2026", activity: "Completed 'Cryptocurrency Fundamentals' lesson 6", type: "learning" },
                { date: "Feb 16, 2026", activity: "Updated portfolio: Added 0.1 BTC", type: "portfolio" },
                { date: "Feb 15, 2026", activity: "Viewed Ethereum rating details", type: "rating" },
                { date: "Feb 14, 2026", activity: "Started 'Bitcoin Deep Dive' course", type: "learning" },
                { date: "Feb 13, 2026", activity: "Viewed Solana rating details", type: "rating" },
                { date: "Feb 12, 2026", activity: "Completed 'Crypto Security & Wallets' lesson 3", type: "learning" },
              ].map((item, index) => (
                <div key={index} className="flex items-start justify-between py-3 border-b border-border last:border-0">
                  <div className="flex-1">
                    <div className="text-sm text-muted-foreground mb-1">{item.date}</div>
                    <div>{item.activity}</div>
                  </div>
                  <Badge variant="outline" className={
                    item.type === "learning" ? "border-neon-green text-neon-green" :
                    item.type === "portfolio" ? "border-neon-cyan text-neon-cyan" :
                    "border-neon-magenta text-neon-magenta"
                  }>
                    {item.type}
                  </Badge>
                </div>
              ))}
            </div>
          </Card>
        </TabsContent>

        {/* Preferences Tab */}
        <TabsContent value="preferences" className="space-y-6">
          <Card className="p-6">
            <h2 className="text-2xl mb-6 flex items-center gap-2">
              <Bell className="w-6 h-6" />
              Notifications
            </h2>
            <div className="space-y-4">
              {[
                { label: "Course updates and new lessons", checked: true },
                { label: "Portfolio price alerts", checked: true },
                { label: "New crypto ratings", checked: false },
                { label: "Weekly newsletter", checked: true },
                { label: "Premium feature announcements", checked: false },
              ].map((pref, index) => (
                <div key={index} className="flex items-center justify-between py-2">
                  <span>{pref.label}</span>
                  <input
                    type="checkbox"
                    defaultChecked={pref.checked}
                    className="w-5 h-5 accent-neon-green"
                  />
                </div>
              ))}
            </div>
          </Card>

          <Card className="p-6">
            <h2 className="text-2xl mb-6 flex items-center gap-2">
              <Settings className="w-6 h-6" />
              Display Preferences
            </h2>
            <div className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="language">Language</Label>
                <select id="language" className="w-full p-2 rounded-lg bg-input-background border border-border">
                  <option>English</option>
                  <option>Spanish</option>
                  <option>French</option>
                  <option>German</option>
                </select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="currency">Default Currency</Label>
                <select id="currency" className="w-full p-2 rounded-lg bg-input-background border border-border">
                  <option>USD ($)</option>
                  <option>EUR (€)</option>
                  <option>GBP (£)</option>
                  <option>JPY (¥)</option>
                </select>
              </div>
            </div>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
```

### `/src/styles/theme.css` (IMPORTANT - Custom Colors)
```css
@custom-variant dark (&:is(.dark *));

:root {
  --font-size: 16px;
  --background: #1a1a1a;
  --foreground: #e0e0e0;
  --card: #2a2a2a;
  --card-foreground: #e0e0e0;
  --popover: #2a2a2a;
  --popover-foreground: #e0e0e0;
  --primary: #00ff9f;
  --primary-foreground: #0a0a0a;
  --secondary: #7928ca;
  --secondary-foreground: #ffffff;
  --muted: #3a3a3a;
  --muted-foreground: #a0a0a0;
  --accent: #ff0080;
  --accent-foreground: #ffffff;
  --neon-cyan: #00ffff;
  --neon-magenta: #ff00ff;
  --neon-green: #00ff9f;
  --neon-yellow: #ffff00;
  --neon-blue: #0080ff;
  --destructive: #ff0055;
  --destructive-foreground: #ffffff;
  --border: rgba(255, 255, 255, 0.1);
  --input: transparent;
  --input-background: #2a2a2a;
  --switch-background: #3a3a3a;
  --font-weight-medium: 500;
  --font-weight-normal: 400;
  --ring: #00ff9f;
  --chart-1: #00ffff;
  --chart-2: #ff00ff;
  --chart-3: #00ff9f;
  --chart-4: #ffff00;
  --chart-5: #0080ff;
  --radius: 0.625rem;
  --sidebar: #1a1a1a;
  --sidebar-foreground: #e0e0e0;
  --sidebar-primary: #00ff9f;
  --sidebar-primary-foreground: #0a0a0a;
  --sidebar-accent: #2a2a2a;
  --sidebar-accent-foreground: #e0e0e0;
  --sidebar-border: rgba(255, 255, 255, 0.1);
  --sidebar-ring: #00ff9f;
}

.dark {
  --background: #1a1a1a;
  --foreground: #e0e0e0;
  --card: #2a2a2a;
  --card-foreground: #e0e0e0;
  --popover: #2a2a2a;
  --popover-foreground: #e0e0e0;
  --primary: #00ff9f;
  --primary-foreground: #0a0a0a;
  --secondary: #7928ca;
  --secondary-foreground: #ffffff;
  --muted: #3a3a3a;
  --muted-foreground: #a0a0a0;
  --accent: #ff0080;
  --accent-foreground: #ffffff;
  --destructive: #ff0055;
  --destructive-foreground: #ffffff;
  --border: rgba(255, 255, 255, 0.1);
  --input: rgba(255, 255, 255, 0.1);
  --ring: #00ff9f;
  --font-weight-medium: 500;
  --font-weight-normal: 400;
  --chart-1: #00ffff;
  --chart-2: #ff00ff;
  --chart-3: #00ff9f;
  --chart-4: #ffff00;
  --chart-5: #0080ff;
  --sidebar: #1a1a1a;
  --sidebar-foreground: #e0e0e0;
  --sidebar-primary: #00ff9f;
  --sidebar-primary-foreground: #0a0a0a;
  --sidebar-accent: #2a2a2a;
  --sidebar-accent-foreground: #e0e0e0;
  --sidebar-border: rgba(255, 255, 255, 0.1);
  --sidebar-ring: #00ff9f;
}

@theme inline {
  --color-background: var(--background);
  --color-foreground: var(--foreground);
  --color-card: var(--card);
  --color-card-foreground: var(--card-foreground);
  --color-popover: var(--popover);
  --color-popover-foreground: var(--popover-foreground);
  --color-primary: var(--primary);
  --color-primary-foreground: var(--primary-foreground);
  --color-secondary: var(--secondary);
  --color-secondary-foreground: var(--secondary-foreground);
  --color-muted: var(--muted);
  --color-muted-foreground: var(--muted-foreground);
  --color-accent: var(--accent);
  --color-accent-foreground: var(--accent-foreground);
  --color-neon-cyan: var(--neon-cyan);
  --color-neon-magenta: var(--neon-magenta);
  --color-neon-green: var(--neon-green);
  --color-neon-yellow: var(--neon-yellow);
  --color-neon-blue: var(--neon-blue);
  --color-destructive: var(--destructive);
  --color-destructive-foreground: var(--destructive-foreground);
  --color-border: var(--border);
  --color-input: var(--input);
  --color-input-background: var(--input-background);
  --color-switch-background: var(--switch-background);
  --color-ring: var(--ring);
  --color-chart-1: var(--chart-1);
  --color-chart-2: var(--chart-2);
  --color-chart-3: var(--chart-3);
  --color-chart-4: var(--chart-4);
  --color-chart-5: var(--chart-5);
  --radius-sm: calc(var(--radius) - 4px);
  --radius-md: calc(var(--radius) - 2px);
  --radius-lg: var(--radius);
  --radius-xl: calc(var(--radius) + 4px);
  --color-sidebar: var(--sidebar);
  --color-sidebar-foreground: var(--sidebar-foreground);
  --color-sidebar-primary: var(--sidebar-primary);
  --color-sidebar-primary-foreground: var(--sidebar-primary-foreground);
  --color-sidebar-accent: var(--sidebar-accent);
  --color-sidebar-accent-foreground: var(--sidebar-accent-foreground);
  --color-sidebar-border: var(--sidebar-border);
  --color-sidebar-ring: var(--sidebar-ring);
}

@layer base {
  * {
    @apply border-border outline-ring/50;
  }

  body {
    @apply bg-background text-foreground;
  }

  html {
    font-size: var(--font-size);
  }

  h1 {
    font-size: var(--text-2xl);
    font-weight: var(--font-weight-medium);
    line-height: 1.5;
  }

  h2 {
    font-size: var(--text-xl);
    font-weight: var(--font-weight-medium);
    line-height: 1.5;
  }

  h3 {
    font-size: var(--text-lg);
    font-weight: var(--font-weight-medium);
    line-height: 1.5;
  }

  h4 {
    font-size: var(--text-base);
    font-weight: var(--font-weight-medium);
    line-height: 1.5;
  }

  label {
    font-size: var(--text-base);
    font-weight: var(--font-weight-medium);
    line-height: 1.5;
  }

  button {
    font-size: var(--text-base);
    font-weight: var(--font-weight-medium);
    line-height: 1.5;
  }

  input {
    font-size: var(--text-base);
    font-weight: var(--font-weight-normal);
    line-height: 1.5;
  }
}
```

---

## Key Features Implemented

### Color Scheme
- **Dark Charcoal Base**: #1a1a1a (background), #2a2a2a (cards)
- **Neon Accents**: 
  - Cyan (#00ffff)
  - Magenta (#ff00ff) 
  - Green (#00ff9f)
  - Yellow (#ffff00)
  - Blue (#0080ff)

### Pages & Routes
1. **Home** (`/`) - Landing with hero, welcome video, features, stats
2. **Crypto Ratings** (`/ratings`) - Searchable list of cryptocurrencies
3. **Crypto Detail** (`/crypto/:id`) - Individual crypto analysis with video
4. **Classroom** (`/classroom`) - 8 courses with progress tracking
5. **Portfolio** (`/portfolio`) - Investment tracker with P&L
6. **About** (`/about`) - Company mission and values
7. **Profile** (`/profile`) - User settings with 4 tabs

### Components
- **Navigation** - Responsive nav with premium upgrade CTA
- **VideoPlayer** - Reusable component with placeholder design
- **Layout** - Main wrapper with navigation and content area

### Data Structure
All crypto data includes:
- Basic info (name, symbol, price, market cap)
- Rating (1-10 scale with color coding)
- Detailed analysis (technology, team, adoption)
- Risks and opportunities
- Video metadata (title, description, URL)
- Premium flag

### Free vs Premium
- Free tier has access to basic features
- Premium content marked with lock icon and yellow badge
- Upgrade CTAs in navigation and profile
- Premium courses locked in classroom

---

## Customization Guide

### To Change Company Name
Replace `[Company Name]` in:
- Navigation.tsx (line 17)
- Home.tsx (title and video)
- About.tsx (page header and email)

### To Add Video URLs
Update `videoUrl` field in cryptoData.ts:
```tsx
videoUrl: "https://your-video-url.com/video.mp4"
```

### To Modify Neon Colors
Edit CSS variables in theme.css:
```css
--neon-cyan: #00ffff;    /* Change to your color */
--neon-green: #00ff9f;   /* Change to your color */
--neon-magenta: #ff00ff; /* Change to your color */
--neon-yellow: #ffff00;  /* Change to your color */
```

### To Add More Cryptocurrencies
Add objects to `cryptoRatings` array in cryptoData.ts

### To Add More Courses
Add objects to `courses` array in Classroom.tsx

---

## Notes for Another AI
- The project uses Tailwind v4 (note the @theme inline syntax)
- All UI components in `/components/ui/` are from shadcn/ui library
- React Router is configured for Data mode pattern
- Color system is fully customizable via CSS variables
- All data is currently mock/static - ready for API integration
- VideoPlayer component is a placeholder - can be replaced with actual video player library
- Navigation state (isPremium) is local - ready for global state management
- Profile data is static - ready for authentication integration

---

## Setup Instructions
1. Ensure all dependencies are installed (see package.json above)
2. Copy all files to their respective paths
3. Run development server with `npm run dev` or `vite`
4. Replace placeholders with actual company name and content
5. Add real video URLs when ready
6. Integrate with backend/API for dynamic data

---

END OF EXPORT
