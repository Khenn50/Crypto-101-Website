
  # Crypto 101 Website

  This is a code bundle for Crypto 101 Website. The original project is available at https://www.figma.com/design/9umO4wxsjLl6CLmdYDIknj/Crypto-101-Website.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  