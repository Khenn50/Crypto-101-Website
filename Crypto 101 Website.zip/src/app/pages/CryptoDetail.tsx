import { useParams, Link } from "react-router";
import { Card } from "../components/ui/card";
import { Badge } from "../components/ui/badge";
import { Button } from "../components/ui/button";
import { VideoPlayer } from "../components/VideoPlayer";
import { ArrowLeft, TrendingUp, TrendingDown, Lock, AlertTriangle, Sparkles } from "lucide-react";
import { cryptoRatings } from "../data/cryptoData";

export function CryptoDetail() {
  const { id } = useParams();
  const crypto = cryptoRatings.find((c) => c.id === id);

  if (!crypto) {
    return (
      <div className="text-center py-12">
        <h2 className="text-2xl mb-4">Cryptocurrency not found</h2>
        <Link to="/ratings">
          <Button>Back to Ratings</Button>
        </Link>
      </div>
    );
  }

  const getRatingColor = (rating: number) => {
    if (rating >= 8.5) return "text-neon-green";
    if (rating >= 7.5) return "text-neon-cyan";
    if (rating >= 6.5) return "text-neon-yellow";
    return "text-accent";
  };

  return (
    <div className="space-y-8 max-w-5xl mx-auto">
      <Link to="/ratings">
        <Button variant="ghost" className="gap-2">
          <ArrowLeft className="w-4 h-4" />
          Back to Ratings
        </Button>
      </Link>

      {/* Header */}
      <div className="flex items-start justify-between">
        <div className="flex items-center gap-4">
          <div className="w-20 h-20 rounded-full bg-gradient-to-br from-neon-cyan to-neon-magenta flex items-center justify-center">
            <span className="text-3xl font-bold">{crypto.symbol.charAt(0)}</span>
          </div>
          <div>
            <div className="flex items-center gap-3 mb-2">
              <h1 className="text-4xl font-bold">{crypto.name}</h1>
              <span className="text-2xl text-muted-foreground">({crypto.symbol})</span>
              {crypto.isPremium && (
                <Badge className="bg-neon-yellow/20 text-neon-yellow border-neon-yellow">
                  <Lock className="w-3 h-3 mr-1" />
                  Premium
                </Badge>
              )}
            </div>
            <Badge variant="outline" className="border-neon-cyan text-neon-cyan">
              {crypto.category}
            </Badge>
          </div>
        </div>
        
        <div className="text-right">
          <div className="text-sm text-muted-foreground mb-1">Overall Rating</div>
          <div className={`text-5xl font-bold ${getRatingColor(crypto.rating)}`}>
            {crypto.rating}
          </div>
        </div>
      </div>

      {/* Price Info */}
      <div className="grid grid-cols-3 gap-4">
        <Card className="p-6">
          <div className="text-sm text-muted-foreground mb-2">Current Price</div>
          <div className="text-3xl font-bold">{crypto.price}</div>
        </Card>
        <Card className="p-6">
          <div className="text-sm text-muted-foreground mb-2">24h Change</div>
          <div className={`text-3xl font-bold flex items-center gap-2 ${crypto.change24h >= 0 ? 'text-neon-green' : 'text-accent'}`}>
            {crypto.change24h >= 0 ? (
              <TrendingUp className="w-6 h-6" />
            ) : (
              <TrendingDown className="w-6 h-6" />
            )}
            {crypto.change24h >= 0 ? '+' : ''}{crypto.change24h}%
          </div>
        </Card>
        <Card className="p-6">
          <div className="text-sm text-muted-foreground mb-2">Market Cap</div>
          <div className="text-3xl font-bold">{crypto.marketCap}</div>
        </Card>
      </div>

      {/* Description */}
      <Card className="p-6">
        <h2 className="text-2xl mb-4">Overview</h2>
        <p className="text-muted-foreground leading-relaxed">{crypto.description}</p>
      </Card>

      {/* Video Section */}
      {crypto.videoTitle && (
        <div className="space-y-3">
          <h2 className="text-2xl">Video Analysis</h2>
          <VideoPlayer 
            title={crypto.videoTitle}
            description={crypto.videoDescription}
            videoUrl={crypto.videoUrl}
          />
        </div>
      )}

      {/* Technology */}
      <Card className="p-6">
        <h2 className="text-2xl mb-4 flex items-center gap-2">
          <span className="text-neon-cyan">●</span> Technology
        </h2>
        <p className="text-muted-foreground leading-relaxed">{crypto.technology}</p>
      </Card>

      {/* Team & Development */}
      <Card className="p-6">
        <h2 className="text-2xl mb-4 flex items-center gap-2">
          <span className="text-neon-green">●</span> Team & Development
        </h2>
        <p className="text-muted-foreground leading-relaxed">{crypto.team}</p>
      </Card>

      {/* Adoption */}
      <Card className="p-6">
        <h2 className="text-2xl mb-4 flex items-center gap-2">
          <span className="text-neon-magenta">●</span> Adoption & Use Cases
        </h2>
        <p className="text-muted-foreground leading-relaxed">{crypto.adoption}</p>
      </Card>

      {/* Risks & Opportunities */}
      <div className="grid md:grid-cols-2 gap-6">
        <Card className="p-6 border-accent/50">
          <h2 className="text-2xl mb-4 flex items-center gap-2">
            <AlertTriangle className="w-6 h-6 text-accent" />
            Risks
          </h2>
          <ul className="space-y-2">
            {crypto.risks.map((risk, index) => (
              <li key={index} className="flex items-start gap-2">
                <span className="text-accent mt-1">•</span>
                <span className="text-muted-foreground">{risk}</span>
              </li>
            ))}
          </ul>
        </Card>

        <Card className="p-6 border-neon-green/50">
          <h2 className="text-2xl mb-4 flex items-center gap-2">
            <Sparkles className="w-6 h-6 text-neon-green" />
            Opportunities
          </h2>
          <ul className="space-y-2">
            {crypto.opportunities.map((opportunity, index) => (
              <li key={index} className="flex items-start gap-2">
                <span className="text-neon-green mt-1">•</span>
                <span className="text-muted-foreground">{opportunity}</span>
              </li>
            ))}
          </ul>
        </Card>
      </div>
    </div>
  );
}