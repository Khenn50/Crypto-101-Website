import { Card } from "../components/ui/card";
import { Badge } from "../components/ui/badge";
import { Button } from "../components/ui/button";
import { Lock, BookOpen, Video, FileText, CheckCircle2 } from "lucide-react";

interface Course {
  id: string;
  title: string;
  description: string;
  level: "Beginner" | "Intermediate" | "Advanced";
  lessons: number;
  duration: string;
  isPremium?: boolean;
  progress?: number;
}

const courses: Course[] = [
  {
    id: "1",
    title: "Cryptocurrency Fundamentals",
    description: "Learn the basics of blockchain technology, cryptocurrencies, and how digital assets work.",
    level: "Beginner",
    lessons: 8,
    duration: "2 hours",
    progress: 75,
  },
  {
    id: "2",
    title: "Bitcoin Deep Dive",
    description: "Comprehensive exploration of Bitcoin's technology, history, and role in the financial system.",
    level: "Beginner",
    lessons: 10,
    duration: "3 hours",
    progress: 30,
  },
  {
    id: "3",
    title: "Smart Contracts & DeFi",
    description: "Understanding smart contracts, decentralized finance, and the Ethereum ecosystem.",
    level: "Intermediate",
    lessons: 12,
    duration: "4 hours",
    isPremium: true,
  },
  {
    id: "4",
    title: "Technical Analysis for Crypto",
    description: "Learn to read charts, identify patterns, and make informed trading decisions.",
    level: "Intermediate",
    lessons: 15,
    duration: "5 hours",
    isPremium: true,
  },
  {
    id: "5",
    title: "Blockchain Development Basics",
    description: "Introduction to building on blockchain platforms and creating decentralized applications.",
    level: "Advanced",
    lessons: 20,
    duration: "8 hours",
    isPremium: true,
  },
  {
    id: "6",
    title: "Advanced Trading Strategies",
    description: "Professional trading techniques, risk management, and portfolio optimization.",
    level: "Advanced",
    lessons: 18,
    duration: "6 hours",
    isPremium: true,
  },
  {
    id: "7",
    title: "Crypto Security & Wallets",
    description: "Best practices for securing your crypto assets and understanding different wallet types.",
    level: "Beginner",
    lessons: 6,
    duration: "2 hours",
    progress: 0,
  },
  {
    id: "8",
    title: "NFTs & Digital Collectibles",
    description: "Explore the world of NFTs, digital art, and the future of digital ownership.",
    level: "Intermediate",
    lessons: 10,
    duration: "3 hours",
    isPremium: true,
  },
];

export function Classroom() {
  const getLevelColor = (level: string) => {
    switch (level) {
      case "Beginner":
        return "border-neon-green text-neon-green";
      case "Intermediate":
        return "border-neon-cyan text-neon-cyan";
      case "Advanced":
        return "border-neon-magenta text-neon-magenta";
      default:
        return "";
    }
  };

  return (
    <div className="space-y-8">
      <div className="space-y-4">
        <h1 className="text-4xl font-bold">Crypto Classroom</h1>
        <p className="text-muted-foreground">
          Master cryptocurrency from fundamentals to advanced concepts with our comprehensive courses.
        </p>
      </div>

      {/* Learning Path Stats */}
      <div className="grid md:grid-cols-4 gap-4">
        <Card className="p-6">
          <BookOpen className="w-8 h-8 text-neon-green mb-2" />
          <div className="text-2xl font-bold">50+</div>
          <div className="text-sm text-muted-foreground">Total Lessons</div>
        </Card>
        <Card className="p-6">
          <Video className="w-8 h-8 text-neon-cyan mb-2" />
          <div className="text-2xl font-bold">30+</div>
          <div className="text-sm text-muted-foreground">Video Tutorials</div>
        </Card>
        <Card className="p-6">
          <FileText className="w-8 h-8 text-neon-yellow mb-2" />
          <div className="text-2xl font-bold">100+</div>
          <div className="text-sm text-muted-foreground">Articles & Guides</div>
        </Card>
        <Card className="p-6">
          <CheckCircle2 className="w-8 h-8 text-neon-magenta mb-2" />
          <div className="text-2xl font-bold">2/8</div>
          <div className="text-sm text-muted-foreground">Courses Completed</div>
        </Card>
      </div>

      {/* Courses Grid */}
      <div className="grid md:grid-cols-2 gap-6">
        {courses.map((course) => (
          <Card
            key={course.id}
            className={`p-6 relative ${course.isPremium ? 'border-neon-yellow/30' : ''}`}
          >
            {course.isPremium && (
              <div className="absolute top-4 right-4">
                <Badge className="bg-neon-yellow/20 text-neon-yellow border-neon-yellow">
                  <Lock className="w-3 h-3 mr-1" />
                  Premium
                </Badge>
              </div>
            )}

            <div className="space-y-4">
              <div>
                <h3 className="text-xl mb-2">{course.title}</h3>
                <p className="text-sm text-muted-foreground">{course.description}</p>
              </div>

              <div className="flex items-center gap-2">
                <Badge variant="outline" className={getLevelColor(course.level)}>
                  {course.level}
                </Badge>
                <span className="text-sm text-muted-foreground">
                  {course.lessons} lessons • {course.duration}
                </span>
              </div>

              {course.progress !== undefined && (
                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span className="text-muted-foreground">Progress</span>
                    <span className="text-neon-green">{course.progress}%</span>
                  </div>
                  <div className="h-2 bg-muted rounded-full overflow-hidden">
                    <div
                      className="h-full bg-neon-green transition-all"
                      style={{ width: `${course.progress}%` }}
                    />
                  </div>
                </div>
              )}

              <Button
                className={
                  course.isPremium
                    ? "w-full bg-gradient-to-r from-neon-yellow/20 to-neon-magenta/20 border border-neon-yellow hover:opacity-90"
                    : course.progress !== undefined && course.progress > 0
                    ? "w-full bg-neon-green text-black hover:bg-neon-green/90"
                    : "w-full"
                }
              >
                {course.progress !== undefined && course.progress > 0
                  ? "Continue Learning"
                  : course.isPremium
                  ? "Unlock with Premium"
                  : "Start Course"}
              </Button>
            </div>
          </Card>
        ))}
      </div>
    </div>
  );
}
