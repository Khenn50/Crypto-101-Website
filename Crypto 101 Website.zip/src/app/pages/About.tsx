import { Card } from "../components/ui/card";
import { Target, Users, Zap, Shield } from "lucide-react";

export function About() {
  return (
    <div className="space-y-12 max-w-4xl mx-auto">
      <div className="text-center space-y-4">
        <h1 className="text-5xl font-bold bg-gradient-to-r from-neon-cyan via-neon-green to-neon-magenta bg-clip-text text-transparent">
          About [Company Name]
        </h1>
        <p className="text-xl text-muted-foreground">
          Empowering investors with knowledge and insights in the cryptocurrency space
        </p>
      </div>

      {/* Mission Statement */}
      <Card className="p-8 border-neon-green/50">
        <h2 className="text-3xl mb-4">Our Mission</h2>
        <p className="text-lg text-muted-foreground leading-relaxed">
          We believe that cryptocurrency represents the future of finance, but navigating this complex landscape can be overwhelming. Our mission is to democratize crypto education and provide transparent, unbiased ratings and analysis to help everyone make informed investment decisions.
        </p>
      </Card>

      {/* Core Values */}
      <div className="grid md:grid-cols-2 gap-6">
        <Card className="p-6">
          <Target className="w-12 h-12 text-neon-green mb-4" />
          <h3 className="text-2xl mb-3">Transparency</h3>
          <p className="text-muted-foreground">
            Our rating methodology is clear and consistent. We provide detailed analysis so you understand exactly how we evaluate each cryptocurrency.
          </p>
        </Card>

        <Card className="p-6">
          <Users className="w-12 h-12 text-neon-cyan mb-4" />
          <h3 className="text-2xl mb-3">Education First</h3>
          <p className="text-muted-foreground">
            We prioritize teaching over selling. Our comprehensive classroom helps you build real knowledge and confidence in the crypto space.
          </p>
        </Card>

        <Card className="p-6">
          <Zap className="w-12 h-12 text-neon-yellow mb-4" />
          <h3 className="text-2xl mb-3">Data-Driven</h3>
          <p className="text-muted-foreground">
            Every rating is backed by thorough research, technical analysis, and real-world adoption metrics. No hype, just facts.
          </p>
        </Card>

        <Card className="p-6">
          <Shield className="w-12 h-12 text-neon-magenta mb-4" />
          <h3 className="text-2xl mb-3">Community Focus</h3>
          <p className="text-muted-foreground">
            We're building a community of informed crypto enthusiasts who support each other's learning journey.
          </p>
        </Card>
      </div>

      {/* What We Offer */}
      <Card className="p-8">
        <h2 className="text-3xl mb-6">What We Offer</h2>
        <div className="space-y-6">
          <div>
            <h3 className="text-xl mb-2 text-neon-green">Comprehensive Ratings</h3>
            <p className="text-muted-foreground">
              In-depth analysis of cryptocurrencies covering technology, team, adoption, and market potential. Our ratings help you cut through the noise.
            </p>
          </div>
          <div>
            <h3 className="text-xl mb-2 text-neon-cyan">Expert Education</h3>
            <p className="text-muted-foreground">
              From blockchain basics to advanced trading strategies, our classroom offers structured learning paths for all experience levels.
            </p>
          </div>
          <div>
            <h3 className="text-xl mb-2 text-neon-magenta">Portfolio Tools</h3>
            <p className="text-muted-foreground">
              Track your investments, analyze performance, and make better decisions with our custom portfolio management tools.
            </p>
          </div>
          <div>
            <h3 className="text-xl mb-2 text-neon-yellow">Premium Insights</h3>
            <p className="text-muted-foreground">
              Premium members get access to exclusive research, advanced analytics, and early access to new ratings and courses.
            </p>
          </div>
        </div>
      </Card>

      {/* Team Placeholder */}
      <Card className="p-8 text-center">
        <h2 className="text-3xl mb-4">Our Team</h2>
        <p className="text-muted-foreground mb-6">
          We're a diverse team of blockchain experts, financial analysts, and educators passionate about cryptocurrency and its potential to transform finance.
        </p>
        <div className="grid md:grid-cols-4 gap-4 mt-8">
          {[1, 2, 3, 4].map((i) => (
            <div key={i} className="space-y-2">
              <div className="w-24 h-24 mx-auto rounded-full bg-gradient-to-br from-neon-cyan to-neon-magenta" />
              <div className="text-muted-foreground text-sm">Team Member</div>
              <div className="text-xs text-muted-foreground">Role</div>
            </div>
          ))}
        </div>
      </Card>

      {/* Contact CTA */}
      <Card className="p-8 text-center bg-gradient-to-r from-neon-green/10 to-neon-cyan/10 border-neon-green/50">
        <h2 className="text-3xl mb-4">Join Our Community</h2>
        <p className="text-muted-foreground mb-6">
          Ready to start your crypto journey? Join thousands of learners and investors making smarter decisions.
        </p>
        <div className="text-neon-green">contact@[company].com</div>
      </Card>
    </div>
  );
}
