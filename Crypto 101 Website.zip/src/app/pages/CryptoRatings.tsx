import { Link } from "react-router";
import { Card } from "../components/ui/card";
import { Badge } from "../components/ui/badge";
import { Input } from "../components/ui/input";
import { Lock, TrendingUp, TrendingDown } from "lucide-react";
import { cryptoRatings } from "../data/cryptoData";
import { useState } from "react";

export function CryptoRatings() {
  const [search, setSearch] = useState("");

  const filteredCryptos = cryptoRatings.filter(
    (crypto) =>
      crypto.name.toLowerCase().includes(search.toLowerCase()) ||
      crypto.symbol.toLowerCase().includes(search.toLowerCase())
  );

  const getRatingColor = (rating: number) => {
    if (rating >= 8.5) return "text-neon-green";
    if (rating >= 7.5) return "text-neon-cyan";
    if (rating >= 6.5) return "text-neon-yellow";
    return "text-accent";
  };

  return (
    <div className="space-y-8">
      <div className="space-y-4">
        <h1 className="text-4xl font-bold">Crypto Rating System</h1>
        <p className="text-muted-foreground">
          Expert analysis and ratings for top cryptocurrencies based on technology, adoption, team, and market potential.
        </p>
        <Input
          type="search"
          placeholder="Search cryptocurrencies..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          className="max-w-md bg-input-background"
        />
      </div>

      <div className="grid gap-4">
        {filteredCryptos.map((crypto) => (
          <Link key={crypto.id} to={`/crypto/${crypto.id}`}>
            <Card className="p-6 hover:border-neon-green transition-colors cursor-pointer relative overflow-hidden">
              {crypto.isPremium && (
                <div className="absolute top-4 right-4">
                  <Badge className="bg-neon-yellow/20 text-neon-yellow border-neon-yellow">
                    <Lock className="w-3 h-3 mr-1" />
                    Premium
                  </Badge>
                </div>
              )}
              
              <div className="flex flex-col md:flex-row md:items-center gap-4">
                <div className="flex items-center gap-4 flex-1">
                  <div className="w-12 h-12 rounded-full bg-gradient-to-br from-neon-cyan to-neon-magenta flex items-center justify-center">
                    <span className="text-xl font-bold">{crypto.symbol.charAt(0)}</span>
                  </div>
                  
                  <div className="flex-1">
                    <div className="flex items-center gap-2">
                      <h3 className="text-xl">{crypto.name}</h3>
                      <span className="text-muted-foreground">({crypto.symbol})</span>
                    </div>
                    <p className="text-sm text-muted-foreground">{crypto.category}</p>
                  </div>
                </div>

                <div className="flex items-center gap-8">
                  <div>
                    <div className="text-sm text-muted-foreground">Price</div>
                    <div className="text-lg">{crypto.price}</div>
                  </div>

                  <div>
                    <div className="text-sm text-muted-foreground">24h Change</div>
                    <div className={`text-lg flex items-center gap-1 ${crypto.change24h >= 0 ? 'text-neon-green' : 'text-accent'}`}>
                      {crypto.change24h >= 0 ? (
                        <TrendingUp className="w-4 h-4" />
                      ) : (
                        <TrendingDown className="w-4 h-4" />
                      )}
                      {crypto.change24h >= 0 ? '+' : ''}{crypto.change24h}%
                    </div>
                  </div>

                  <div>
                    <div className="text-sm text-muted-foreground">Market Cap</div>
                    <div className="text-lg">{crypto.marketCap}</div>
                  </div>

                  <div className="text-center">
                    <div className="text-sm text-muted-foreground mb-1">Rating</div>
                    <div className={`text-3xl font-bold ${getRatingColor(crypto.rating)}`}>
                      {crypto.rating}
                    </div>
                  </div>
                </div>
              </div>
            </Card>
          </Link>
        ))}
      </div>
    </div>
  );
}
