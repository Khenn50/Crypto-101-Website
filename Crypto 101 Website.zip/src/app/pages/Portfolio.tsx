import { Card } from "../components/ui/card";
import { Button } from "../components/ui/button";
import { Badge } from "../components/ui/badge";
import { Plus, TrendingUp, TrendingDown, Wallet, PieChart, DollarSign } from "lucide-react";
import { useState } from "react";

interface PortfolioItem {
  id: string;
  crypto: string;
  symbol: string;
  amount: number;
  avgPrice: number;
  currentPrice: number;
  value: number;
  change: number;
  changePercent: number;
}

export function Portfolio() {
  const [portfolioItems] = useState<PortfolioItem[]>([
    {
      id: "1",
      crypto: "Bitcoin",
      symbol: "BTC",
      amount: 0.5,
      avgPrice: 42000,
      currentPrice: 45230,
      value: 22615,
      change: 1615,
      changePercent: 7.69,
    },
    {
      id: "2",
      crypto: "Ethereum",
      symbol: "ETH",
      amount: 5,
      avgPrice: 2200,
      currentPrice: 2420,
      value: 12100,
      change: 1100,
      changePercent: 10.0,
    },
    {
      id: "3",
      crypto: "Cardano",
      symbol: "ADA",
      amount: 1000,
      avgPrice: 0.55,
      currentPrice: 0.52,
      value: 520,
      change: -30,
      changePercent: -5.45,
    },
  ]);

  const totalValue = portfolioItems.reduce((sum, item) => sum + item.value, 0);
  const totalChange = portfolioItems.reduce((sum, item) => sum + item.change, 0);
  const totalChangePercent = (totalChange / (totalValue - totalChange)) * 100;

  return (
    <div className="space-y-8">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-4xl font-bold mb-2">My Portfolio</h1>
          <p className="text-muted-foreground">
            Track and manage your cryptocurrency investments
          </p>
        </div>
        <Button className="bg-neon-green text-black hover:bg-neon-green/90">
          <Plus className="w-4 h-4 mr-2" />
          Add Asset
        </Button>
      </div>

      {/* Portfolio Summary */}
      <div className="grid md:grid-cols-4 gap-4">
        <Card className="p-6 border-neon-green/50">
          <div className="flex items-center justify-between mb-2">
            <Wallet className="w-8 h-8 text-neon-green" />
          </div>
          <div className="text-sm text-muted-foreground mb-1">Total Value</div>
          <div className="text-3xl font-bold">${totalValue.toLocaleString()}</div>
        </Card>

        <Card className="p-6">
          <div className="flex items-center justify-between mb-2">
            {totalChange >= 0 ? (
              <TrendingUp className="w-8 h-8 text-neon-green" />
            ) : (
              <TrendingDown className="w-8 h-8 text-accent" />
            )}
          </div>
          <div className="text-sm text-muted-foreground mb-1">Total P&L</div>
          <div className={`text-3xl font-bold ${totalChange >= 0 ? 'text-neon-green' : 'text-accent'}`}>
            {totalChange >= 0 ? '+' : ''}${totalChange.toLocaleString()}
          </div>
        </Card>

        <Card className="p-6">
          <div className="flex items-center justify-between mb-2">
            <DollarSign className="w-8 h-8 text-neon-cyan" />
          </div>
          <div className="text-sm text-muted-foreground mb-1">Total Return</div>
          <div className={`text-3xl font-bold ${totalChangePercent >= 0 ? 'text-neon-green' : 'text-accent'}`}>
            {totalChangePercent >= 0 ? '+' : ''}{totalChangePercent.toFixed(2)}%
          </div>
        </Card>

        <Card className="p-6">
          <div className="flex items-center justify-between mb-2">
            <PieChart className="w-8 h-8 text-neon-magenta" />
          </div>
          <div className="text-sm text-muted-foreground mb-1">Holdings</div>
          <div className="text-3xl font-bold">{portfolioItems.length}</div>
        </Card>
      </div>

      {/* Portfolio Holdings */}
      <Card className="p-6">
        <h2 className="text-2xl mb-6">Holdings</h2>
        <div className="space-y-4">
          {portfolioItems.map((item) => (
            <div
              key={item.id}
              className="flex items-center justify-between p-4 rounded-lg bg-muted/30 hover:bg-muted/50 transition-colors"
            >
              <div className="flex items-center gap-4 flex-1">
                <div className="w-12 h-12 rounded-full bg-gradient-to-br from-neon-cyan to-neon-magenta flex items-center justify-center">
                  <span className="font-bold">{item.symbol.charAt(0)}</span>
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <span className="font-medium">{item.crypto}</span>
                    <span className="text-muted-foreground text-sm">({item.symbol})</span>
                  </div>
                  <div className="text-sm text-muted-foreground">
                    {item.amount} {item.symbol}
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-4 gap-8 text-right">
                <div>
                  <div className="text-sm text-muted-foreground mb-1">Avg Price</div>
                  <div>${item.avgPrice.toLocaleString()}</div>
                </div>

                <div>
                  <div className="text-sm text-muted-foreground mb-1">Current Price</div>
                  <div>${item.currentPrice.toLocaleString()}</div>
                </div>

                <div>
                  <div className="text-sm text-muted-foreground mb-1">Value</div>
                  <div className="font-medium">${item.value.toLocaleString()}</div>
                </div>

                <div>
                  <div className="text-sm text-muted-foreground mb-1">P&L</div>
                  <div className={`font-medium ${item.change >= 0 ? 'text-neon-green' : 'text-accent'}`}>
                    {item.change >= 0 ? '+' : ''}${item.change.toLocaleString()}
                    <Badge
                      variant="outline"
                      className={`ml-2 ${item.changePercent >= 0 ? 'border-neon-green text-neon-green' : 'border-accent text-accent'}`}
                    >
                      {item.changePercent >= 0 ? '+' : ''}{item.changePercent.toFixed(2)}%
                    </Badge>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </Card>

      {/* Portfolio Allocation */}
      <Card className="p-6">
        <h2 className="text-2xl mb-6">Portfolio Allocation</h2>
        <div className="space-y-4">
          {portfolioItems.map((item) => {
            const percentage = (item.value / totalValue) * 100;
            return (
              <div key={item.id}>
                <div className="flex justify-between mb-2">
                  <span>{item.crypto}</span>
                  <span className="text-muted-foreground">{percentage.toFixed(2)}%</span>
                </div>
                <div className="h-3 bg-muted rounded-full overflow-hidden">
                  <div
                    className="h-full bg-gradient-to-r from-neon-cyan to-neon-magenta"
                    style={{ width: `${percentage}%` }}
                  />
                </div>
              </div>
            );
          })}
        </div>
      </Card>
    </div>
  );
}
