import { Link } from "react-router";
import { Button } from "../components/ui/button";
import { Card } from "../components/ui/card";
import { VideoPlayer } from "../components/VideoPlayer";
import { TrendingUp, GraduationCap, Wallet, Star } from "lucide-react";

export function Home() {
  return (
    <div className="space-y-16">
      {/* Hero Section */}
      <section className="text-center space-y-6 py-12">
        <h1 className="text-5xl md:text-7xl font-bold bg-gradient-to-r from-neon-cyan via-neon-green to-neon-magenta bg-clip-text text-transparent">
          Welcome to Crypto 101
        </h1>
        <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
          Your gateway to understanding cryptocurrency. Learn, analyze, and build your crypto knowledge with expert ratings and education.
        </p>
        <div className="flex gap-4 justify-center">
          <Link to="/ratings">
            <Button className="bg-neon-green text-black hover:bg-neon-green/90">
              Explore Ratings
            </Button>
          </Link>
          <Link to="/classroom">
            <Button variant="outline" className="border-neon-cyan text-neon-cyan hover:bg-neon-cyan/10">
              Start Learning
            </Button>
          </Link>
        </div>
      </section>

      {/* Welcome Video Section */}
      <section className="max-w-4xl mx-auto space-y-4">
        <div className="text-center space-y-2">
          <h2 className="text-3xl font-bold">Welcome Video</h2>
          <p className="text-muted-foreground">
            Get started with a quick introduction to our platform and what we offer
          </p>
        </div>
        <VideoPlayer 
          title="Welcome to [Company Name] - Your Crypto Journey Starts Here"
          description="Learn about our mission, features, and how we can help you navigate the crypto space"
        />
      </section>

      {/* Features Grid */}
      <section className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Link to="/ratings">
          <Card className="p-6 hover:border-neon-green transition-colors cursor-pointer h-full">
            <Star className="w-12 h-12 text-neon-green mb-4" />
            <h3 className="text-xl mb-2">Crypto Ratings</h3>
            <p className="text-muted-foreground">
              Expert analysis and ratings for top cryptocurrencies
            </p>
          </Card>
        </Link>

        <Link to="/classroom">
          <Card className="p-6 hover:border-neon-cyan transition-colors cursor-pointer h-full">
            <GraduationCap className="w-12 h-12 text-neon-cyan mb-4" />
            <h3 className="text-xl mb-2">Classroom</h3>
            <p className="text-muted-foreground">
              Learn crypto fundamentals from beginner to advanced
            </p>
          </Card>
        </Link>

        <Link to="/portfolio">
          <Card className="p-6 hover:border-neon-magenta transition-colors cursor-pointer h-full">
            <Wallet className="w-12 h-12 text-neon-magenta mb-4" />
            <h3 className="text-xl mb-2">Portfolio</h3>
            <p className="text-muted-foreground">
              Build and track your custom crypto portfolio
            </p>
          </Card>
        </Link>

        <Card className="p-6 border-neon-yellow h-full">
          <TrendingUp className="w-12 h-12 text-neon-yellow mb-4" />
          <h3 className="text-xl mb-2">Premium Access</h3>
          <p className="text-muted-foreground">
            Unlock advanced features and exclusive content
          </p>
        </Card>
      </section>

      {/* Stats Section */}
      <section className="grid md:grid-cols-3 gap-8 py-12">
        <div className="text-center">
          <div className="text-4xl font-bold text-neon-cyan mb-2">100+</div>
          <div className="text-muted-foreground">Cryptocurrencies Rated</div>
        </div>
        <div className="text-center">
          <div className="text-4xl font-bold text-neon-green mb-2">50+</div>
          <div className="text-muted-foreground">Learning Modules</div>
        </div>
        <div className="text-center">
          <div className="text-4xl font-bold text-neon-magenta mb-2">10K+</div>
          <div className="text-muted-foreground">Active Users</div>
        </div>
      </section>
    </div>
  );
}