import { Card } from "../components/ui/card";
import { Button } from "../components/ui/button";
import { Input } from "../components/ui/input";
import { Label } from "../components/ui/label";
import { Badge } from "../components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "../components/ui/tabs";
import { 
  User, 
  Mail, 
  Crown, 
  Settings, 
  Bell, 
  Shield,
  BookOpen,
  TrendingUp,
  Award
} from "lucide-react";
import { useState } from "react";

export function Profile() {
  const [isPremium] = useState(false);

  return (
    <div className="space-y-8 max-w-5xl mx-auto">
      {/* Profile Header */}
      <div className="flex items-start justify-between">
        <div className="flex items-center gap-6">
          <div className="w-24 h-24 rounded-full bg-gradient-to-br from-neon-cyan to-neon-magenta flex items-center justify-center">
            <User className="w-12 h-12" />
          </div>
          <div>
            <h1 className="text-3xl font-bold mb-2">User Profile</h1>
            <div className="flex items-center gap-3">
              <Badge variant="outline" className="border-neon-green text-neon-green">
                Free Member
              </Badge>
              <span className="text-muted-foreground">Member since Feb 2026</span>
            </div>
          </div>
        </div>

        {!isPremium && (
          <Button className="bg-gradient-to-r from-neon-magenta to-neon-cyan text-white hover:opacity-90">
            <Crown className="w-4 h-4 mr-2" />
            Upgrade to Premium
          </Button>
        )}
      </div>

      <Tabs defaultValue="overview" className="w-full">
        <TabsList className="grid w-full grid-cols-4 mb-8">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="settings">Settings</TabsTrigger>
          <TabsTrigger value="activity">Activity</TabsTrigger>
          <TabsTrigger value="preferences">Preferences</TabsTrigger>
        </TabsList>

        {/* Overview Tab */}
        <TabsContent value="overview" className="space-y-6">
          <div className="grid md:grid-cols-3 gap-6">
            <Card className="p-6">
              <BookOpen className="w-8 h-8 text-neon-green mb-3" />
              <div className="text-2xl font-bold mb-1">12</div>
              <div className="text-sm text-muted-foreground">Courses Started</div>
            </Card>

            <Card className="p-6">
              <Award className="w-8 h-8 text-neon-cyan mb-3" />
              <div className="text-2xl font-bold mb-1">3</div>
              <div className="text-sm text-muted-foreground">Courses Completed</div>
            </Card>

            <Card className="p-6">
              <TrendingUp className="w-8 h-8 text-neon-magenta mb-3" />
              <div className="text-2xl font-bold mb-1">5</div>
              <div className="text-sm text-muted-foreground">Portfolio Holdings</div>
            </Card>
          </div>

          {/* Learning Progress */}
          <Card className="p-6">
            <h2 className="text-2xl mb-6">Learning Progress</h2>
            <div className="space-y-4">
              <div>
                <div className="flex justify-between mb-2">
                  <span>Cryptocurrency Fundamentals</span>
                  <span className="text-neon-green">75%</span>
                </div>
                <div className="h-2 bg-muted rounded-full overflow-hidden">
                  <div className="h-full bg-neon-green" style={{ width: "75%" }} />
                </div>
              </div>
              <div>
                <div className="flex justify-between mb-2">
                  <span>Bitcoin Deep Dive</span>
                  <span className="text-neon-cyan">30%</span>
                </div>
                <div className="h-2 bg-muted rounded-full overflow-hidden">
                  <div className="h-full bg-neon-cyan" style={{ width: "30%" }} />
                </div>
              </div>
              <div>
                <div className="flex justify-between mb-2">
                  <span>Crypto Security & Wallets</span>
                  <span className="text-muted-foreground">0%</span>
                </div>
                <div className="h-2 bg-muted rounded-full overflow-hidden">
                  <div className="h-full bg-muted" style={{ width: "0%" }} />
                </div>
              </div>
            </div>
          </Card>

          {/* Recent Activity */}
          <Card className="p-6">
            <h2 className="text-2xl mb-6">Recent Activity</h2>
            <div className="space-y-4">
              {[
                { action: "Completed lesson", course: "Bitcoin Fundamentals", time: "2 hours ago" },
                { action: "Added to portfolio", course: "Ethereum (ETH)", time: "1 day ago" },
                { action: "Started course", course: "Smart Contracts & DeFi", time: "3 days ago" },
                { action: "Viewed rating", course: "Cardano (ADA)", time: "1 week ago" },
              ].map((activity, index) => (
                <div key={index} className="flex items-center justify-between py-2 border-b border-border last:border-0">
                  <div>
                    <div className="font-medium">{activity.action}</div>
                    <div className="text-sm text-muted-foreground">{activity.course}</div>
                  </div>
                  <div className="text-sm text-muted-foreground">{activity.time}</div>
                </div>
              ))}
            </div>
          </Card>
        </TabsContent>

        {/* Settings Tab */}
        <TabsContent value="settings" className="space-y-6">
          <Card className="p-6">
            <h2 className="text-2xl mb-6 flex items-center gap-2">
              <User className="w-6 h-6" />
              Profile Information
            </h2>
            <div className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="name">Full Name</Label>
                <Input id="name" defaultValue="John Doe" />
              </div>
              <div className="space-y-2">
                <Label htmlFor="email">Email</Label>
                <Input id="email" type="email" defaultValue="john@example.com" />
              </div>
              <div className="space-y-2">
                <Label htmlFor="username">Username</Label>
                <Input id="username" defaultValue="johndoe" />
              </div>
              <Button className="bg-neon-green text-black hover:bg-neon-green/90">
                Save Changes
              </Button>
            </div>
          </Card>

          <Card className="p-6">
            <h2 className="text-2xl mb-6 flex items-center gap-2">
              <Shield className="w-6 h-6" />
              Security
            </h2>
            <div className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="current-password">Current Password</Label>
                <Input id="current-password" type="password" />
              </div>
              <div className="space-y-2">
                <Label htmlFor="new-password">New Password</Label>
                <Input id="new-password" type="password" />
              </div>
              <div className="space-y-2">
                <Label htmlFor="confirm-password">Confirm New Password</Label>
                <Input id="confirm-password" type="password" />
              </div>
              <Button variant="outline">Update Password</Button>
            </div>
          </Card>
        </TabsContent>

        {/* Activity Tab */}
        <TabsContent value="activity" className="space-y-6">
          <Card className="p-6">
            <h2 className="text-2xl mb-6">Activity History</h2>
            <div className="space-y-4">
              {[
                { date: "Feb 17, 2026", activity: "Completed 'Cryptocurrency Fundamentals' lesson 6", type: "learning" },
                { date: "Feb 16, 2026", activity: "Updated portfolio: Added 0.1 BTC", type: "portfolio" },
                { date: "Feb 15, 2026", activity: "Viewed Ethereum rating details", type: "rating" },
                { date: "Feb 14, 2026", activity: "Started 'Bitcoin Deep Dive' course", type: "learning" },
                { date: "Feb 13, 2026", activity: "Viewed Solana rating details", type: "rating" },
                { date: "Feb 12, 2026", activity: "Completed 'Crypto Security & Wallets' lesson 3", type: "learning" },
              ].map((item, index) => (
                <div key={index} className="flex items-start justify-between py-3 border-b border-border last:border-0">
                  <div className="flex-1">
                    <div className="text-sm text-muted-foreground mb-1">{item.date}</div>
                    <div>{item.activity}</div>
                  </div>
                  <Badge variant="outline" className={
                    item.type === "learning" ? "border-neon-green text-neon-green" :
                    item.type === "portfolio" ? "border-neon-cyan text-neon-cyan" :
                    "border-neon-magenta text-neon-magenta"
                  }>
                    {item.type}
                  </Badge>
                </div>
              ))}
            </div>
          </Card>
        </TabsContent>

        {/* Preferences Tab */}
        <TabsContent value="preferences" className="space-y-6">
          <Card className="p-6">
            <h2 className="text-2xl mb-6 flex items-center gap-2">
              <Bell className="w-6 h-6" />
              Notifications
            </h2>
            <div className="space-y-4">
              {[
                { label: "Course updates and new lessons", checked: true },
                { label: "Portfolio price alerts", checked: true },
                { label: "New crypto ratings", checked: false },
                { label: "Weekly newsletter", checked: true },
                { label: "Premium feature announcements", checked: false },
              ].map((pref, index) => (
                <div key={index} className="flex items-center justify-between py-2">
                  <span>{pref.label}</span>
                  <input
                    type="checkbox"
                    defaultChecked={pref.checked}
                    className="w-5 h-5 accent-neon-green"
                  />
                </div>
              ))}
            </div>
          </Card>

          <Card className="p-6">
            <h2 className="text-2xl mb-6 flex items-center gap-2">
              <Settings className="w-6 h-6" />
              Display Preferences
            </h2>
            <div className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="language">Language</Label>
                <select id="language" className="w-full p-2 rounded-lg bg-input-background border border-border">
                  <option>English</option>
                  <option>Spanish</option>
                  <option>French</option>
                  <option>German</option>
                </select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="currency">Default Currency</Label>
                <select id="currency" className="w-full p-2 rounded-lg bg-input-background border border-border">
                  <option>USD ($)</option>
                  <option>EUR (€)</option>
                  <option>GBP (£)</option>
                  <option>JPY (¥)</option>
                </select>
              </div>
            </div>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
