import { createBrowserRouter } from "react-router";
import { Layout } from "./components/Layout";
import { Home } from "./pages/Home";
import { CryptoRatings } from "./pages/CryptoRatings";
import { CryptoDetail } from "./pages/CryptoDetail";
import { Classroom } from "./pages/Classroom";
import { Portfolio } from "./pages/Portfolio";
import { About } from "./pages/About";
import { Profile } from "./pages/Profile";

export const router = createBrowserRouter([
  {
    path: "/",
    Component: Layout,
    children: [
      { index: true, Component: Home },
      { path: "ratings", Component: CryptoRatings },
      { path: "crypto/:id", Component: CryptoDetail },
      { path: "classroom", Component: Classroom },
      { path: "portfolio", Component: Portfolio },
      { path: "about", Component: About },
      { path: "profile", Component: Profile },
    ],
  },
]);
