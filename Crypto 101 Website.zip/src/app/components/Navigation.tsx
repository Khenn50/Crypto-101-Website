import { Link, useLocation } from "react-router";
import { Button } from "./ui/button";
import { Crown, User } from "lucide-react";
import { useState } from "react";

export function Navigation() {
  const location = useLocation();
  const [isPremium, setIsPremium] = useState(false);

  const navItems = [
    { path: "/", label: "Home" },
    { path: "/ratings", label: "Crypto Ratings" },
    { path: "/classroom", label: "Classroom" },
    { path: "/portfolio", label: "Portfolio" },
    { path: "/about", label: "About" },
  ];

  const isActive = (path: string) => {
    if (path === "/") {
      return location.pathname === "/";
    }
    return location.pathname.startsWith(path);
  };

  return (
    <nav className="border-b border-border bg-card">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between h-16">
          <div className="flex items-center gap-8">
            <Link to="/" className="flex items-center gap-2">
              <div className="w-8 h-8 bg-gradient-to-br from-neon-cyan to-neon-magenta rounded-lg" />
              <span className="text-xl text-neon-green">[Company Name]</span>
            </Link>
            
            <div className="hidden md:flex gap-1">
              {navItems.map((item) => (
                <Link key={item.path} to={item.path}>
                  <Button
                    variant="ghost"
                    className={
                      isActive(item.path)
                        ? "text-neon-green hover:text-neon-green"
                        : "text-muted-foreground hover:text-foreground"
                    }
                  >
                    {item.label}
                  </Button>
                </Link>
              ))}
            </div>
          </div>

          <div className="flex items-center gap-4">
            {!isPremium && (
              <Button
                onClick={() => setIsPremium(true)}
                className="bg-gradient-to-r from-neon-magenta to-neon-cyan text-white hover:opacity-90"
              >
                <Crown className="w-4 h-4 mr-2" />
                Upgrade to Premium
              </Button>
            )}
            {isPremium && (
              <div className="flex items-center gap-2 px-3 py-1 rounded-full bg-gradient-to-r from-neon-magenta/20 to-neon-cyan/20 border border-neon-cyan">
                <Crown className="w-4 h-4 text-neon-yellow" />
                <span className="text-sm text-neon-yellow">Premium</span>
              </div>
            )}
            <Link to="/profile">
              <Button variant="ghost" size="icon">
                <User className="w-5 h-5" />
              </Button>
            </Link>
          </div>
        </div>
      </div>
    </nav>
  );
}
