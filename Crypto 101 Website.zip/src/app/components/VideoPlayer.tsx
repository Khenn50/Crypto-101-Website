import { Card } from "./ui/card";
import { Play } from "lucide-react";

interface VideoPlayerProps {
  title?: string;
  videoUrl?: string;
  thumbnailUrl?: string;
  description?: string;
}

export function VideoPlayer({ 
  title, 
  videoUrl = "", 
  thumbnailUrl = "",
  description 
}: VideoPlayerProps) {
  return (
    <Card className="overflow-hidden">
      <div className="relative aspect-video bg-gradient-to-br from-muted to-muted/50 flex items-center justify-center group cursor-pointer">
        {thumbnailUrl ? (
          <img 
            src={thumbnailUrl} 
            alt={title || "Video thumbnail"} 
            className="w-full h-full object-cover"
          />
        ) : (
          <div className="text-center space-y-4">
            <div className="w-20 h-20 mx-auto rounded-full bg-neon-green/20 border-2 border-neon-green flex items-center justify-center group-hover:scale-110 transition-transform">
              <Play className="w-10 h-10 text-neon-green fill-neon-green" />
            </div>
            <div className="text-muted-foreground">
              {title || "Video Player"}
            </div>
          </div>
        )}
        <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
          <div className="w-20 h-20 rounded-full bg-neon-green/90 flex items-center justify-center">
            <Play className="w-10 h-10 text-black fill-black ml-1" />
          </div>
        </div>
      </div>
      {(title || description) && (
        <div className="p-4">
          {title && <h3 className="font-medium mb-1">{title}</h3>}
          {description && <p className="text-sm text-muted-foreground">{description}</p>}
        </div>
      )}
    </Card>
  );
}
